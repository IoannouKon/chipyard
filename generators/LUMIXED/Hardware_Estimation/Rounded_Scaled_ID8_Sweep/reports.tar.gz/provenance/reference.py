"""Independent integer-exact IEEE FP32 RNE references; no host FP32 sums/FMA."""
import importlib.util,sys,csv,math,struct,collections
from pathlib import Path
s=importlib.util.spec_from_file_location('vectors',Path(__file__).with_name('vector_reference.py'));V=importlib.util.module_from_spec(s);sys.modules[s.name]=V;s.loader.exec_module(V)
NAN=0x7fc00000
def isinf(a):return a&0x7fffffff==0x7f800000
def isnan(a):return a&0x7fffffff>0x7f800000
def zero(a):return a&0x7fffffff==0
def add(a,b):
 if isnan(a) or isnan(b) or isinf(a) and isinf(b) and ((a^b)>>31):return NAN
 if isinf(a):return a
 if isinf(b):return b
 n=V.fp_fixed(a,32)+V.fp_fixed(b,32)
 return V.fixed_to_fp32_bits(n,149) if n else (0x80000000 if a==b==0x80000000 else 0)
def fma(a,b,c):
 if any(map(isnan,[a,b,c])) or (isinf(a) and zero(b)) or (isinf(b) and zero(a)):return NAN
 sign=(a^b)>>31
 if isinf(a) or isinf(b):return NAN if isinf(c) and sign!=(c>>31) else (sign<<31)|0x7f800000
 if isinf(c):return c
 n=V.fp_fixed(a,32)*V.fp_fixed(b,32)+(V.fp_fixed(c,32)<<149)
 if n:return V.fixed_to_fp32_bits(n,298)
 return 0x80000000 if (zero(a) or zero(b)) and zero(c) and sign and c>>31 else 0

def fragments(k,n,bits,g,B=8,RF=4):
 cap=B*RF*(1<<(8-bits));banks=[[] for _ in range(B)]
 for start in range(0,k,cap):
  length=min(cap,k-start);span=(length+B-1)//B
  for col in range(n):
   for b in range(B):
    lo=start+b*span;hi=min(start+length,lo+span)
    while lo<hi:
     end=min(hi,(lo//g+1)*g);banks[b].append((col,lo//g,list(range(lo,end))));lo=end
 return [collections.deque(x) for x in banks]

def reference(x,q,scales,r,k,n,bits,g,mode,trace=None,B=8,RF=4,YS=4):
 if mode=='off_exact':return V.unscaled_matmul(x,q,r,k,n,32) if hasattr(V,'unscaled_matmul') else [V.fixed_to_fp32_bits(sum(V.fp_fixed(x[y*k+i],32)*q[c][i] for i in range(k)),149) for y in range(r) for c in range(n)]
 if mode=='off_rounded':
  cap=B*RF*(1<<(8-bits));out=[]
  for y in range(r):
   for c in range(n):
    acc=0
    for st in range(0,k,cap):
     length=min(cap,k-st);span=(length+B-1)//B
     for pos in range(span):
      inds=[st+b*span+pos for b in range(B) if st+b*span+pos<st+length]
      sub=sum(V.fp_fixed(x[y*k+i],32)*q[c][i] for i in inds);acc=add(acc,V.fixed_to_fp32_bits(sub,149))
    out.append(acc)
  return out
 if mode=='on_exact':
  result=V.grouped_matmul(x,q,scales,r,k,n,g,32)
  # Still validate fragment trace coverage/order independently below.
 else:result=None
 banks=fragments(k,n,bits,g,B,RF);out=[0]*(r*n);initialized=set();events=0;row_base=0
 for ev in csv.DictReader(Path(trace).open()):
  c=int(ev['column'])
  if int(ev['initialize']):
   if c in initialized:
    assert len(initialized)==n and not any(banks) and row_base+YS<r,('premature row-group initialization',c,row_base)
    row_base+=YS;banks=fragments(k,n,bits,g,B,RF);initialized=set()
   initialized.add(c)
   for y in range(row_base,min(row_base+YS,r)):out[y*n+c]=0
   continue
  b=int(ev['bank']);assert banks[b],('extra bank fragment',b)
  col,group,inds=banks[b].popleft();assert (col,group)==(c,int(ev['group'])),('fragment order/coverage',(col,group),ev)
  assert c in initialized,('fragment before initialization',ev)
  scale=V.fp16_fixed24(scales[group*n+c]);scale_bits=((scales[group*n+c]&0x8000)<<16) if scale==0 else V.fixed_to_fp32_bits(scale,24)
  for y in range(row_base,min(row_base+YS,r)):
   partial=sum(V.fp_fixed(x[y*k+i],32)*q[c][i] for i in inds)
   if mode=='on_a':out[y*n+c]=add(out[y*n+c],V.fixed_to_fp32_bits(partial*scale,173))
   elif mode=='on_b':out[y*n+c]=fma(V.fixed_to_fp32_bits(partial,149),scale_bits,out[y*n+c])
  events+=1
 assert len(initialized)==n and not any(banks) and row_base+YS>=r,('missing fragments',len(initialized),[len(b) for b in banks])
 return result if result is not None else out

def fp(a):return struct.unpack('<f',struct.pack('<I',a))[0]
def ordered(a):return (~a&0xffffffff) if a>>31 else a|0x80000000
def metrics(actual,exact):
 pairs=[(fp(a),fp(e)) for a,e in zip(actual,exact) if math.isfinite(fp(a)) and math.isfinite(fp(e))];diff=[a-e for a,e in pairs]
 norm=sum(e*e for a,e in pairs);anorm=sum(a*a for a,e in pairs);dot=sum(a*e for a,e in pairs)
 ulps=[abs(ordered(a)-ordered(e)) for a,e in zip(actual,exact) if not(isnan(a) or isnan(e) or isinf(a) or isinf(e))]
 return dict(relative_l2=math.sqrt(sum(d*d for d in diff)/norm) if norm else (0 if not any(diff) else None),mae=sum(map(abs,diff))/max(1,len(diff)),max_abs=max(map(abs,diff),default=0),rmse=math.sqrt(sum(d*d for d in diff)/max(1,len(diff))),cosine=dot/math.sqrt(norm*anorm) if norm and anorm else None,bit_identical_percent=100*sum(a==e for a,e in zip(actual,exact))/len(actual),max_ulp=max(ulps,default=0),mean_ulp=sum(ulps)/max(1,len(ulps)),unexpected_nonfinite=sum((isinf(a) or isnan(a)) and not(isinf(e) or isnan(e)) for a,e in zip(actual,exact)),nonfinite_outputs=sum(isinf(a) or isnan(a) for a in actual),finite_pairs=len(pairs))

if __name__=='__main__':
 # IEEE identities/ties and a fused cancellation where mul+add would differ.
 assert add(0x3f800000,0x33800000)==0x3f800000
 assert add(0x3f800001,0x33800000)==0x3f800002
 assert fma(0x3f800001,0x3f7ffffe,0xbf800000)==0xa8800000
 assert fma(0x7f800000,0,0)==NAN
 assert fma(0x80000000,0x3f800000,0x80000000)==0x80000000
 print('Independent integer reference unit checks PASS')
