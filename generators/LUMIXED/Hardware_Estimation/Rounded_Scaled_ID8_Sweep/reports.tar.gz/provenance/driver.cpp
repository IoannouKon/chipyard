#ifndef EXP_BANKS
#define EXP_BANKS 8
#endif
#include "VRegisteredContext.h"
#include "verilated.h"
#include "verilated_vpi.h"
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <stdexcept>
static vpiHandle handle(const char* n){auto h=vpi_handle_by_name((PLI_BYTE8*)n,nullptr);if(!h)throw std::runtime_error(std::string("Missing VPI object: ")+n);return h;}
static void put(vpiHandle h,uint64_t n){s_vpi_value v{};s_vpi_vecval bits[2]{};bits[0].aval=n;bits[1].aval=n>>32;v.format=vpiVectorVal;v.value.vector=bits;vpi_put_value(h,&v,nullptr,vpiNoDelay);}
static uint64_t get(vpiHandle h){s_vpi_value v{};v.format=vpiVectorVal;vpi_get_value(h,&v);return uint64_t(uint32_t(v.value.vector[0].aval)) | (vpi_get(vpiSize,h)>32 ? (uint64_t(uint32_t(v.value.vector[1].aval))<<32) : 0);}
int main(int argc,char**argv){
 if(argc!=9){fprintf(stderr,"Usage: sim K N bits memory.bin output-memory.bin seed G R\n");return 3;}
 auto ctx=new VerilatedContext;ctx->commandArgs(argc,argv);auto top=new VRegisteredContext(ctx);
 std::vector<uint8_t> observed(65536,0xa5);uint32_t seenWrites=0;
 bool tracing=false;uint64_t traceCycle=0,fifoStalls=0,selectionStalls=0;
 std::ofstream trace(std::string(argv[5]).substr(0,std::string(argv[5]).find_last_of('/'))+"/fragment_order.csv");trace<<"cycle,initialize,bank,column,group\n";
 vpiHandle initV=nullptr,initR=nullptr,initC=nullptr,arbV=nullptr,arbR=nullptr,arbC=nullptr,arbG=nullptr,can=nullptr,readOn=nullptr;
 std::vector<vpiHandle> ready,valid;
 auto tick=[&](){top->clock=0;top->eval();
 if(tracing){
  if(get(initV)&&(initR ? get(initR) : 1))trace<<traceCycle<<",1,-1,"<<get(initC)<<",0\n";
  if(get(arbV)&&(arbR ? get(arbR) : !get(initV))){
   int chosen=-1;for(int b=0;b<EXP_BANKS;b++)if(get(ready[b])&&get(valid[b])){if(chosen!=-1)throw std::runtime_error("Multiple FIFO pops");chosen=b;}
   if(chosen<0)throw std::runtime_error("Missing fragment FIFO pop");
   trace<<traceCycle<<",0,"<<chosen<<","<<get(arbC)<<","<<get(arbG)<<"\n";
  }
  if(get(arbV)&&!(arbR ? get(arbR) : !get(initV)))fifoStalls++;
  if(!get(can)&&get(readOn))selectionStalls++;
  traceCycle++;
 }
ctx->timeInc(1);top->clock=1;top->eval();ctx->timeInc(1);top->clock=0;top->eval();if(top->io_writeCount!=seenWrites){
    if(top->io_writeCount!=seenWrites+1)throw std::runtime_error("Write capture count jumped");
    seenWrites=top->io_writeCount;
    uint32_t address=top->io_lastWriteAddress;if(address+8>observed.size())throw std::runtime_error("Bad write address");
    for(int b=0;b<8;b++)if(top->io_lastWriteMask&(1<<b))observed[address+b]=top->io_lastWriteData>>(b*8);
  }
  if(ctx->gotFinish())throw std::runtime_error("RTL stopped/assertion");};
 top->reset=1;for(int i=0;i<8;i++)tick();top->reset=0;
 put(handle("TOP.RegisteredContext.initialized"),1); // Context-only SRAM initialization is supplied below; DUT untouched.
 auto mem=handle("TOP.RegisteredContext.backing_ext.Memory");
 std::ifstream f(argv[4],std::ios::binary);if(!f)return 5;
 for(int i=0;i<8192;i++){uint64_t data=0;f.read((char*)&data,8);put(vpi_handle_by_index(mem,i),data);}
 put(handle("TOP.RegisteredContext.cfgK"),strtoul(argv[1],0,0));put(handle("TOP.RegisteredContext.cfgN"),strtoul(argv[2],0,0));put(handle("TOP.RegisteredContext.cfgBits"),strtoul(argv[3],0,0));put(handle("TOP.RegisteredContext.rng"),strtoull(argv[6],0,0)|1);
 put(handle("TOP.RegisteredContext.cfgGroup"),strtoul(argv[7],0,0));
 if(strtoul(argv[7],0,0)){
 const std::string prefix="TOP.RegisteredContext.core.groupEngine.";
 auto h=[&](std::string n){return handle((prefix+n).c_str());};
 initV=h("_initializes_io_deq_valid");initR=vpi_handle_by_name((PLI_BYTE8*)(prefix+"initializes.io_deq_ready").c_str(),nullptr);initC=h("_initializes_io_deq_bits_column");
 arbV=h("_arb_io_out_valid");arbR=vpi_handle_by_name((PLI_BYTE8*)(prefix+"arb.io_out_ready").c_str(),nullptr);arbC=h("_arb_io_out_bits_column");arbG=h("_arb_io_out_bits_group");can=h("io_canIssue");readOn=handle("TOP.RegisteredContext.core.READ_ON");
 for(int b=0;b<EXP_BANKS;b++){ready.push_back(h("_arb_io_in_"+std::to_string(b)+"_ready"));valid.push_back(h("_fifos_"+std::to_string(b)+"_io_deq_valid"));}
 // Full-parallel engine has selected.ready=1; absent constant VPI pins use that verified identity.
 tracing=true;
 }
 uint64_t cycles=0;while(!top->io_completedJobs && cycles<100000000){tick();cycles++;}
 if(!top->io_completedJobs){fprintf(stderr,"TIMEOUT after %lu cycles busy commands\n",cycles);return 6;}
 std::ofstream out(argv[5],std::ios::binary);for(int i=0;i<8192;i++){uint64_t data=get(vpi_handle_by_index(mem,i));out.write((char*)&data,8);}out.close();
 std::ofstream payload(std::string(argv[5]).substr(0,std::string(argv[5]).find_last_of('/'))+"/write_payload.bin",std::ios::binary);
 unsigned n=strtoul(argv[2],0,0);payload.write((char*)&observed[0xf008],4*strtoul(argv[8],0,0)*n);payload.close();
 printf("RESULT cycles=%lu counters=%lu,%lu,%lu,%lu,%lu,%lu command_stalls=%u memory_stalls=%u response_stalls=%u write_beats=%u read_beats=%u\n",cycles,top->io_counters_0,top->io_counters_1,top->io_counters_2,top->io_counters_3,top->io_counters_4,top->io_counters_5,top->io_commandStalls,top->io_memoryStalls,top->io_responseStalls,top->io_writeCount,top->io_readCount);
 printf("OBSERVED fragment_fifo_backpressure=%lu selection_credit_stalls=%lu\n",fifoStalls,selectionStalls);trace.close();
 top->final();delete top;delete ctx;return 0;
}
