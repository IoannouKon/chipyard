#!/usr/bin/env python3
"""Sequential committed automatic rounded group-scaling U250 evaluation.
Scaling ON only; completed OFF baselines are reused. No production source edits.
"""
from pathlib import Path
import os,sys,json,subprocess,time,hashlib,shutil,traceback,re,csv,signal,datetime,importlib.util,struct,math,fcntl,zipfile
R=Path(__file__).resolve().parent;CY=Path('/var/tmp/lumixed-rounded-scaling.3q0lokdm/worktree');T=Path('/home/kioannou/chipyard_1.13.0/.conda-env')
sys.dont_write_bytecode=True
PLAN=json.loads((R/'plan.json').read_text());CURRENT=None;CHILD=None;START=time.monotonic()
def now():return datetime.datetime.now().astimezone().isoformat()
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def state(phase,**kw):
 s=dict(phase=phase,time=now(),runner_pid=os.getpid(),case=CURRENT,cpus=sorted(os.sched_getaffinity(0)),**kw);save(R/'status.json',s)
 if CURRENT:save(R/'cases'/CURRENT/'runner_status.json',s)
 print(s,flush=True)
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
PARSERS=load('ppa_parser',R/'scripts/report_parsers.py')
ENV=os.environ.copy();ENV.update(PATH='/home/kioannou/.local/opt/firtool-1.75.0/bin:'+str(T/'bin')+':'+str(T/'riscv-tools/bin')+':'+ENV.get('PATH',''),LD_LIBRARY_PATH=str(T/'lib'),RISCV=str(T/'riscv-tools'),CHISEL_FIRTOOL_PATH='/home/kioannou/.local/opt/firtool-1.75.0/bin',JAVA_TOOL_OPTIONS='-Xmx4G -Xss8M -XX:ActiveProcessorCount=8',PPA_MAX_THREADS='8',PPA_REUSE_SYNTH='0',MAKEFLAGS='-j8',CXX=str(T/'bin/x86_64-conda-linux-gnu-g++'),CC=str(T/'bin/x86_64-conda-linux-gnu-gcc'))
ENV.update(HOME=str(R/'java-home'),TMPDIR=str(R/'tmp'),TMP=str(R/'tmp'),TEMP=str(R/'tmp'),XDG_CACHE_HOME=str(R/'xdg'),COURSIER_CACHE=str(R/'coursier'),CCACHE_DIR=str(R/'ccache'),JAVA_TOOL_OPTIONS=f'-Xmx4G -Xss8M -XX:ActiveProcessorCount=8 -Djava.io.tmpdir={R}/tmp -Duser.home={R}/java-home')
def run(cmd,log,phase,env=None,timeout=3600,cwd=R):
 global CHILD
 if shutil.disk_usage(R).free < PLAN['min_free_gib']*1024**3:raise RuntimeError('DISK_GUARD: fewer than 8 GiB free; no files deleted')
 remaining=PLAN['batch_timeout_seconds']-(time.monotonic()-START)
 if remaining<=0:raise RuntimeError('BATCH_TIMEOUT')
 cmd=list(map(str,cmd));timeout=min(timeout,remaining);save(log.with_suffix('.command.json'),dict(command=cmd,cwd=str(cwd),time=now(),timeout_seconds=timeout,max_threads=8,cpus=sorted(os.sched_getaffinity(0))))
 log.parent.mkdir(parents=True,exist_ok=True)
 with log.open('wb') as f:
  CHILD=subprocess.Popen(cmd,cwd=cwd,env=env or ENV,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  state(phase,child_pid=CHILD.pid,log=str(log))
  try:code=CHILD.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(CHILD.pid,signal.SIGTERM)
   try:CHILD.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(CHILD.pid,signal.SIGKILL);CHILD.wait()
   save(log.with_suffix('.timeout.json'),dict(time=now(),timeout_seconds=timeout));CHILD=None;raise RuntimeError('TIMED_OUT: '+str(log))
  CHILD=None
 if code:raise RuntimeError(f'EXIT_{code}: {log}; '+log.read_text(errors='replace')[-1800:])
def stop(sig,frame):
 if CHILD and CHILD.poll() is None:
  try:os.killpg(CHILD.pid,signal.SIGTERM);CHILD.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(CHILD.pid,signal.SIGKILL)
 state('STOPPED',signal=sig);raise SystemExit(128+sig)
for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,stop)
def prod_unchanged():
 expected=json.loads((R/'provenance.json').read_text())
 assert subprocess.check_output(['git','-C',CY,'rev-parse','HEAD'],text=True).strip()==expected['production_head'],'Production revision changed during batch'
 # Changes by another user/agent are not reverted or touched by this runner.
 assert hashlib.sha256(subprocess.check_output(['git','-C',CY,'status','--porcelain=v1','-z'])).hexdigest()==expected['production_status_sha256'],'Production status changed during batch'
 for n,h in expected['snapshot_source_sha256'].items():assert sha(R/'evaluation_source'/n)==h
 assert sha(R/'toolchain/chipyard.jar')==expected['compiled_jar_sha256']
def select_cpus():
 def sample():
  return {int(a[0][3:]):list(map(int,a[1:])) for l in Path('/proc/stat').read_text().splitlines() if (a:=l.split()) and a[0].startswith('cpu') and a[0]!='cpu'}
 a=sample();time.sleep(.25);b=sample();eligible=os.sched_getaffinity(0);groups={};usage={}
 for cpu in eligible:
  topo=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology');socket=int((topo/'physical_package_id').read_text());core=int((topo/'core_id').read_text());v=[y-x for x,y in zip(a[cpu],b[cpu])];usage[cpu]=1-(v[3]+v[4])/max(1,sum(v));groups.setdefault(socket,{}).setdefault(core,[]).append(cpu)
 choices=[]
 for socket,cores in groups.items():
  cpus=sorted((min(threads,key=usage.get) for threads in cores.values()),key=usage.get)[:8]
  if cpus:choices.append((socket,cpus))
 socket,cpus=min(choices,key=lambda x:(-len(x[1]),sum(usage[c] for c in x[1])));os.sched_setaffinity(0,cpus);os.nice(10)
 save(R/'cpu_selection.json',dict(socket=socket,physical_cpus=cpus,usage_fraction=usage,nice=os.nice(0),load=os.getloadavg(),time=now()))
def tsv(p):
 if not p.exists():return {}
 return dict(l.split('\t',1) for l in p.read_text().splitlines() if '\t' in l)
def summary():
 rows=[]
 for c in PLAN['cases']:
  d=R/'cases'/c['id'];out=d/'implementation';status=tsv(out/'status.tsv');failure=json.loads((d/'failure.json').read_text()) if (d/'failure.json').exists() else {};ret={s:tsv(out/f'retention_{s}.tsv') for s in ['linked','opt_design','phys_opt_design','route_design']}
  # Each retention TSV has three columns: parse PASS independently.
  retained=all((out/f'retention_{s}.tsv').exists() and 'retained_full_core\t1\t1' in (out/f'retention_{s}.tsv').read_text() for s in ret)
  routed=(out/'post_route.dcp').exists() and status.get('status','').startswith('ROUTED_') and retained
  resource=out/'utilization_post_route.rpt' if routed else out/'utilization_post_place.rpt'
  if not resource.exists():resource=out/'utilization_post_synth.rpt'
  scope='wrapped'
  if not resource.exists():resource=d/'core/utilization_post_synth.rpt';scope='standalone_core'
  resource_stage='post_route' if routed else ('placed' if resource.name=='utilization_post_place.rpt' else ('post_synthesis' if resource.exists() else 'not_run'))
  row=dict(case=c['id'],B=c['B'],RF=c['RF'],YS=c['YS'],DMA_ID=8,scaling='ON',arithmetic='rounded_group_FMA',status=status.get('status','NOT_RUN'),stage=status.get('stage','not_run'),valid_routed_ppa=routed,resource_scope=scope,resource_stage=resource_stage,**PARSERS.parse_utilization(resource))
  if failure:row['status']='TIMED_OUT' if 'TIME' in failure.get('error','') else 'FAILED';row['error']=failure.get('error')
  if routed:
   row.update(PARSERS.parse_power(out/'power_post_route_vectorless.rpt'))
   for k in ['worst_setup_slack_ns','worst_hold_slack_ns','estimated_fmax_mhz']:
    try:row[k]=float(status[k])
    except (ValueError,KeyError):row[k]=None
  if routed:
   for label in ['internal_setup','internal_hold','core_internal_setup','core_internal_hold']:
    report=out/(label+'.rpt')
    if report.exists():
     slacks=re.findall(r'slack\s*\([^)]*\)\s*(-?[0-9.]+)',report.read_text(errors='replace'),re.I)
     if slacks:row[label+'_ns']=min(map(float,slacks))
  rows.append(row)
 off=list(csv.DictReader(Path(PLAN['off_baseline']).open()))
 for row in rows:
  match=next(v for v in off if int(v['B'])==row['B'] and int(v['RF'])==row['RF'] and int(v['YS'])==row['YS'])
  row['off_baseline']=match['case'];row['off_baseline_dynamic_w']=float(match['dynamic_w']);row['off_baseline_total_w']=float(match['total_w']);row['off_baseline_estimated_fmax_mhz']=float(match['estimated_fmax_mhz'])
  if row.get('valid_routed_ppa') and row.get('dynamic_w') is not None:row['top_dynamic_change_vs_off_percent']=100*(row['dynamic_w']/float(match['dynamic_w'])-1)
 save(R/'summary.json',rows);keys=list(dict.fromkeys(k for row in rows for k in row))
 with (R/'summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
 def v(row,k):return str(row.get(k,'—'))
 lines=['# Rounded group-scaled U250 sweep','', 'Completed evidence only; missing routed metrics are unknown. Power is vectorless; Fmax is setup-derived, not a board maximum. Only scaling ON is executed; OFF baselines are reused separately.','', '| Config | Stage/status | LUT | FF | DSP | BRAM36/18 | URAM | Dynamic W | Static W | Total W | Setup ns | Hold ns | Est. MHz |','|---|---|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|']
 for x in rows:lines.append('| '+' | '.join([x['case'],x['resource_scope']+'/'+x['resource_stage']+'/'+x['status'],v(x,'lut_total'),v(x,'ff'),v(x,'dsp'),v(x,'bram36')+'/'+v(x,'bram18'),v(x,'uram'),v(x,'dynamic_w'),v(x,'static_w'),v(x,'total_w'),v(x,'worst_setup_slack_ns'),v(x,'worst_hold_slack_ns'),v(x,'estimated_fmax_mhz')])+' |')
 (R/'RESULTS.md').write_text('\n'.join(lines)+'\n')
def core(c,d):
 cached=d/'rtl'/(c['id']+'.json')
 if cached.exists():return json.loads(cached.read_text())
 cls='PPARoundedSweep';overlay=d/'overlay';overlay.mkdir();B,RF,YS=c['B'],c['RF'],c['YS']
 text=f'''package ppa
import org.chipsalliance.cde.config.Config
class {cls} extends Config(new Config((site,here,up)=>{{
 case LUMIXED_PACKAGE.LUMIXEDParamsKey => LUMIXED_PACKAGE.LUMIXED_Config.LUMIXED_Config.copy(
 Rin=4,Cin=3072,Cout=3072,banks_per_row={B},table_capacity_factor={RF},parallel_rows={YS},
 FP_ACTIVATIONS=true,FP_BITS=32,WBitWidth=8,OutBitWidth=32,DMA_Bytes=8,Dma_Ids=8,W_BUFFS=2,
 ROUNDED_ACCUMULATION=true,GROUP_SCALE_ALIGNED=false,GROUP_SCALE_DEFERRED=true,GROUP_SCALE_YS={YS},DEBUG=true,
 SKIP_ZERO_WEIGHTS=false,FLEXIBLE_BANK_GROUPING=false,WEIGHT_DMA_BURSTS=false,EARLY_WEIGHT_BUFFER_RELEASE=false)
}}) ++ new chipyard.LUMIXEDRocketConfig)
'''
 (overlay/(cls+'.scala')).write_text(text);save(overlay/'overlay.json',dict(config_class=cls,package='ppa'));overlays=d/'overlays';overlays.mkdir();shutil.copytree(overlay,overlays/c['id'])
 save(d/'plan.json',dict(designs=[dict(c,accelerator='LUMIXED')]))
 run([sys.executable,R/'scripts/elaborate_rtl.py','--repo',CY,'--plan',d/'plan.json','--overlays',overlays,'--out',d/'elaboration','--rtl-dir',d/'rtl','--jar',R/'toolchain/chipyard.jar','--tapeout',R/'toolchain/tapeout.jar','--tools-prefix',T],d/'elaborate.log','ELABORATE_CORE',timeout=1200)
 run([sys.executable,R/'scripts/review_rtl.py','--plan',d/'plan.json','--rtl-dir',d/'rtl'],d/'review.log','REVIEW_CORE',timeout=120)
 m=json.loads((d/'rtl'/(c['id']+'.json')).read_text());m['evaluation_source_provenance']=dict(snapshot=str(R/'evaluation_source'),source_sha256=json.loads((R/'provenance.json').read_text())['snapshot_source_sha256'],compiled_jar_sha256=sha(R/'toolchain/chipyard.jar'),note='Package worktree fingerprints are cache invalidation only; generator accelerator classes come from this verified committed a6c24594 automatic rounded-group FMA JAR.');save(d/'rtl'/(c['id']+'.json'),m)
 assert any(Path(v).name=='GroupScaleEngine.sv' for v in m['sources'])
 assert not any(Path(v).name.startswith('ExactScaleMultiplier') for v in m['sources']),'Wide scale multiplier must be absent in rounded FMA mode'
 assert 'GROUP_SCALE_ROUNDING' not in (R/'evaluation_source/Config.scala').read_text()
 return m

def wrapper(c,d):
 if (d/'wrapper_rtl/RegisteredContext.sv').exists():return d/'wrapper_rtl/RegisteredContext.sv'
 text=(R/'RegisteredContext.template.scala').read_text();base=c['B']*c['RF'];YS=c['YS'];assert base & (base-1)==0
 text=text.replace('val slotsMax = 64.U(16.W)',f'val slotsMax = {base}.U(16.W)')
 if base!=64:
  old='val windows = Wire(UInt(16.W)); windows := Mux(cfgBits===8.U,(cfgK+63.U(16.W))>>6,Mux(cfgBits===4.U,(cfgK+1023.U(16.W))>>10,1.U))';assert old in text
  caps=[base,base*16,base*64];e=[f'(cfgK+{cap-1}.U(16.W))>>{int(math.log2(cap))}' for cap in caps]
  text=text.replace(old,f'val windows = Wire(UInt(16.W)); windows := Mux(cfgBits===8.U,{e[0]},Mux(cfgBits===4.U,{e[1]},{e[2]}))')
 text=text.replace('cmdRs2:=(2.U(64.W)<<32)|2.U',f'cmdRs2:=({4//YS}.U(64.W)<<32)|{YS}.U')
 p=d/'RegisteredContext.scala';p.write_text(text);classes=d/'wrapper_classes';classes.mkdir();el=load('elab_'+c['id'],R/'scripts/elaborate_rtl.py');plugin=Path('/home/kioannou/.cache/coursier/v1/https/repo1.maven.org/maven2/org/chipsalliance/chisel-plugin_2.13.16/6.7.0/chisel-plugin_2.13.16-6.7.0.jar')
 run([T/'bin/java','-cp',':'.join(el.compiler_jars(CY)),'scala.tools.nsc.Main','-classpath',R/'toolchain/chipyard.jar',f'-Xplugin:{plugin}','-d',classes,p],d/'wrapper_compile.log','COMPILE_WRAPPER',timeout=300)
 run([T/'bin/java','-cp',str(classes)+':'+str(R/'toolchain/chipyard.jar'),'EmitContext',d/'wrapper_rtl'],d/'wrapper_emit.log','EMIT_WRAPPER',timeout=300)
 return d/'wrapper_rtl/RegisteredContext.sv'
REF=load('group_reference',R/'reference.py')
def add(a,b):
 isnan=lambda v:(v&0x7fffffff)>0x7f800000;inf=lambda v:(v&0x7fffffff)==0x7f800000
 if isnan(a) or isnan(b) or inf(a) and inf(b) and (a^b)>>31:return 0x7fc00000
 if inf(a):return a
 if inf(b):return b
 val=REF.fp_fixed(a,32)+REF.fp_fixed(b,32)
 return REF.fixed_to_fp32_bits(val,149) if val else (0x80000000 if a==b==0x80000000 else 0)
def expected(x,w,k,n,bits,c):
 cap=c['B']*c['RF']*(1<<(8-bits));out=[]
 for row in range(4):
  for col in range(n):
   acc=0
   for start in range(0,k,cap):
    span=(min(k-start,cap)+c['B']-1)//c['B']
    for pos in range(span):
     inds=[start+bank*span+pos for bank in range(c['B']) if start+bank*span+pos<min(k,start+cap)]
     value=sum(REF.fp_fixed(x[row*k+i],32)*w[col*k+i] for i in inds);acc=add(acc,REF.fixed_to_fp32_bits(value,149))
   out.append(acc)
 return struct.pack('<'+'I'*len(out),*out)
def smoke(c,d,m,ws):
 obj=d/'verilator';obj.mkdir(exist_ok=True);(obj/'sources.f').write_text('\n'.join(map(str,[ws,*m['sources']]))+'\n')
 if not (obj/'VRegisteredContext').exists():
  run([T/'bin/verilator','--cc','--exe','--build','-j','8','--top-module','RegisteredContext','--Mdir',obj,'--assert','--vpi','--public-flat-rw','-Wno-fatal','-CFLAGS',f"-O1 -std=c++17 -DEXP_BANKS={c['B']}",*[f'-I{x}' for x in m['include_dirs']],'-f',obj/'sources.f',R/'driver.cpp'],d/'verilator_build.log','BUILD_SCALED_SMOKE',timeout=1800)
 records=[]
 for bits in [8,4,2]:
  for g,k,n in [(32,68,3),(64,132,3),(128,260,3),(128,64,1)]:
   label=f'W{bits}_G{g}_K{k}_N{n}';q=d/'smoke'/label;q.mkdir(parents=True,exist_ok=True)
   v=REF.V.prepare(4,k,n,32,bits,seed=20261127+bits+k,pattern=2,fp_activations=True,group_scale_mode=2,group_size=g)
   rng=REF.V.newlib_rand(20261127+bits+k);v.inputs=[((next(rng)&1)<<31)|((111+next(rng)%25)<<23)|(next(rng)&0x7fffff) for _ in range(4*k)]
   xb=struct.pack('<'+'I'*len(v.inputs),*v.inputs);wb=bytes(value & 0xff for value in v.packed_weights);sb=struct.pack('<'+'H'*len(v.scales),*v.scales);weights=[]
   for col in range(n):
    vals=[]
    for i in range(k):
     j=col*k+i;w=(wb[j*bits//8]>>(j*bits%8))&((1<<bits)-1);vals.append(w-(1<<bits) if w&(1<<(bits-1)) else w)
    weights.append(vals)
   mem=bytearray([0xa5])*65536;mem[:len(xb)]=xb;mem[0x8000:0x8000+len(wb)]=wb;mem[0xd000:0xd000+len(sb)]=sb;(q/'memory.bin').write_bytes(mem)
   run([obj/'VRegisteredContext',k,n,bits,q/'memory.bin',q/'memory_output.bin',hex(0x12345+bits),g,4],q/'verilator.log','VERIFY_SCALED_WRAPPER',timeout=180)
   expected=REF.reference(v.inputs,weights,v.scales,4,k,n,bits,g,'on_b',q/'fragment_order.csv',B=c['B'],RF=c['RF'],YS=c['YS']);exp=struct.pack('<'+'I'*len(expected),*expected);(q/'expected.bin').write_bytes(exp)
   raw=(q/'memory_output.bin').read_bytes();got=raw[0xf008:0xf008+len(exp)];guards=raw[0xf000:0xf008]==mem[0xf000:0xf008] and raw[0xf008+len(exp):0xf010+len(exp)]==mem[0xf008+len(exp):0xf010+len(exp)]
   record=dict(case=label,result='PASS' if got==exp and guards and (q/'write_payload.bin').read_bytes()==got else 'FAIL',elements=len(exp)//4,guards=guards,G=g,rows=4,parallel_rows=c['YS'],B=c['B'],RF=c['RF'],input_sha256=hashlib.sha256(xb).hexdigest(),weights_sha256=hashlib.sha256(wb).hexdigest(),scales_sha256=hashlib.sha256(sb).hexdigest(),output_sha256=hashlib.sha256(got).hexdigest(),reference='Arbitrary precision fragment RNE + single-round FP32 FMA; trace order and full row-group coverage validated')
   save(q/'verification.json',record);assert record['result']=='PASS',record;records.append(record)
 save(d/'smoke_summary.json',dict(result='PASS',tests=len(records),elements=sum(x['elements'] for x in records),scaling='ON',rounded=True))

def evaluate(c,d):
 assert c['scaling']=='ON' and c['ROUNDED_ACCUMULATION'] and c['GROUP_SCALE_DEFERRED'] and not c['GROUP_SCALE_ALIGNED'] and c['GROUP_SCALE_YS']==c['YS']
 m=core(c,d);ws=wrapper(c,d);smoke(c,d,m,ws)
 co=d/'core';co.mkdir(exist_ok=True);(co/'sources.txt').write_text('\n'.join(m['sources'])+'\n');(co/'include_dirs.txt').write_text('\n'.join(m['include_dirs'])+'\n')
 if not ((co/'post_synth.dcp').exists() and tsv(co/'status.tsv').get('status')=='SYNTH_PASS'):
  run([PLAN['vivado'],'-mode','batch','-nojournal','-log',co/'vivado.log','-source',R/'flow/core_synthesis.tcl','-tclargs','LUMIXEDExample',co/'sources.txt',co/'include_dirs.txt',PLAN['part'],'clock','20','synth',co],co/'console.log','SYNTHESIZE_STANDALONE_CORE',timeout=3600)
 resources=PARSERS.parse_utilization(co/'utilization_post_synth.rpt');assert resources['lut_total']>10000 and resources['bram36']>0 and resources['dsp']>0,resources
 with zipfile.ZipFile(co/'post_synth.dcp') as z:
  name=next(n for n in z.namelist() if n.endswith('_stub.v'));stub=z.read(name).decode().replace('module LUMIXEDExample(', '(* black_box = "true" *)\nmodule LUMIXEDExample(');(co/'core_stub.v').write_text(stub)
 export=d/'export.tcl';export.write_text(f'set_param general.maxThreads 8\nopen_checkpoint {{{co}/post_synth.dcp}}\nset_param general.maxThreads 8\nwrite_edif -force {{{co}/LUMIXEDExample.edf}}\nexit\n')
 if not ((d/'implementation/post_synth.dcp').exists() and tsv(d/'implementation/status.tsv').get('status')=='SYNTH_PASS'):
  run([PLAN['vivado'],'-mode','batch','-nojournal','-nolog','-source',export],d/'export.log','EXPORT_CORE_NETLIST',timeout=600)
 out=d/'implementation';out.mkdir(exist_ok=True);(out/'sources.txt').write_text(str(ws)+'\n'+str(co/'core_stub.v')+'\n');(out/'include_dirs.txt').write_text('\n'.join(m['include_dirs'])+'\n')
 e=ENV.copy();e.update(PPA_CORE_EDIF=str(co/'LUMIXEDExample.edf'),PPA_EXPECT_LUTS=str(resources['lut_total']),PPA_EXPECT_FFS=str(resources['ff']),PPA_EXPECT_DSP=str(resources['dsp']),PPA_EXPECT_FMAS=str(c['YS']),PPA_EXPECT_BRAM36=str(resources['bram36']),PPA_EXPECT_BRAM18=str(resources['bram18']),PPA_EXPECT_URAM=str(resources['uram']),PPA_REUSE_LINKED='0')
 cmd=[PLAN['vivado'],'-mode','batch','-nojournal','-log',out/'synth.log','-source',R/'flow/vivado_ppa_ooc.tcl','-tclargs','RegisteredContext',out/'sources.txt',out/'include_dirs.txt',PLAN['part'],'clock','20','synth',out]
 if not ((out/'post_synth.dcp').exists() and tsv(out/'status.tsv').get('status')=='SYNTH_PASS' and (out/'retention_linked.tsv').exists() and 'retained_full_core\t1\t1' in (out/'retention_linked.tsv').read_text()):
  run(cmd,out/'synth_console.log','SYNTHESIZE_AND_VALIDATE_WRAPPED_CORE',env=e,timeout=3600)
 assert tsv(out/'status.tsv')['status']=='SYNTH_PASS'
 identity={str(p):sha(p) for p in [ws,co/'LUMIXEDExample.edf',co/'post_synth.dcp',out/'post_synth.dcp',*list((R/'flow').glob('*.tcl'))]};save(out/'validated_identity.json',identity)
 for p,h in identity.items():assert sha(p)==h
 e['PPA_REUSE_LINKED']='1';cmd[cmd.index('synth')]='route';cmd[cmd.index(out/'synth.log')]=out/'vivado.log'
 run(cmd,out/'console.log','IMPLEMENT_WRAPPED_CORE',env=e,timeout=PLAN['implementation_timeout_seconds'])

def main():
 global CURRENT
 lock=(R/'runner.lock').open('w')
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise SystemExit('Runner already active')
 select_cpus();state('STARTED',scaling_on='ENABLED',arithmetic='ROUNDED_ACCUMULATION=true; automatic group FP32 FMA',case_count=4)
 try:
  for c in PLAN['cases']:
   CURRENT=c['id'];d=R/'cases'/CURRENT;d.mkdir(exist_ok=True);save(d/'configuration.json',c)
   try:prod_unchanged();evaluate(c,d);state('CASE_COMPLETE',vivado_status=tsv(d/'implementation/status.tsv'))
   except Exception as ex:save(d/'failure.json',dict(error=str(ex),time=now()));state('CASE_FAILED',error=str(ex));traceback.print_exc()
   summary()
  CURRENT=None;prod_unchanged();state('COMPLETE',note='Terminal batch status; inspect summary for each case outcome. Four rounded scaling-ON cases; OFF evidence reused, not rerun.');summary()
 except BaseException as ex:
  if not isinstance(ex,SystemExit):state('FAILED',error=str(ex));traceback.print_exc()
  summary();raise
if __name__=='__main__':
 action=sys.argv[1] if len(sys.argv)>1 else 'status'
 if action=='worker':main()
 elif action=='status':
  print((R/'status.json').read_text() if (R/'status.json').exists() else 'Not started')
  if (R/'summary.csv').exists():print((R/'summary.csv').read_text())
 elif action in ('start','resume'):
  f=(R/'runner.lock').open('a')
  try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise SystemExit('Runner already active')
  if action=='start' and any((R/'cases'/c['id']).exists() for c in PLAN['cases']):raise SystemExit('Case evidence already exists; preserve it and use a new run directory for another batch.')
  f.close()
  with (R/'runner.log').open('ab',buffering=0) as log:
   p=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'worker'],cwd=R,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (R/'worker.pid').write_text(str(p.pid)+'\n');print('Started detached worker PID',p.pid,'in',R)
 else:raise SystemExit('Usage: run_sweep.py start|status|worker')
