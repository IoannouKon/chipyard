#!/usr/bin/env python3
"""Detached six-design implementation sweep using verified synthesis checkpoints.

One Vivado job at a time; up to eight CPU threads; unchanged OOC constraints.
Uses the supplied PPA runner/flow, with extra internal/interface timing reports.
"""
from pathlib import Path
import argparse,csv,datetime,fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,traceback
ROOT=Path(__file__).resolve().parent
PACKAGE=Path('/home/kioannou/lumixed_v1_ppa_package')
REPO=Path('/home/kioannou/chipyard_1.15.0')
UPDATED=Path('/home/kioannou/artifacts/lumixed_scaled_id8_synthesis_20261124')
FIRST=Path('/home/kioannou/artifacts/lumixed_scale_multiplier_synth_20261124')
VIVADO='/tools/Xilinx/Vivado/2023.2/bin/vivado'
PART='xcu250-figd2104-2-e'
THREADS=8
TARGET_MHZ=50
# Gemmini first: these arrays have not yet been implemented in the old sweep.
DESIGNS=[
 'gemmini_edited_4_4_W8_R4',
 'gemmini_edited_8_8_W8_R4',
 'lumixed_scaled_B8_RF8_YS2_ID8_R4',
 'lumixed_scaled_B4_RF4_YS4_ID8_R4',
 'lumixed_scaled_B8_RF4_YS4_ID8_R4',
 'lumixed_scaled_B16_RF4_YS2_ID8_R4',
]

def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def now():return datetime.datetime.now().astimezone().isoformat()
def write_json(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def state(phase,**extra):
 d=dict(phase=phase,pid=os.getpid(),updated=now(),threads=THREADS,target_mhz=TARGET_MHZ,part=PART,designs=DESIGNS,**extra);write_json(ROOT/'status.json',d);print(d,flush=True)
def origin(id):
 if id.startswith('gemmini'):return PACKAGE/'work'
 return FIRST if id=='lumixed_scaled_B8_RF8_YS2_ID8_R4' else UPDATED
def status_table():
 sys.path.insert(0,str(ROOT/'flow'));from run_vivado import parse_utilization,parse_timing_checks,tsv
 rows=[]
 for id in DESIGNS:
  job=ROOT/'results'/PART/id;f=job/'metrics.json';m=json.loads(f.read_text()) if f.exists() else {};live=tsv(job/'status.tsv') if (job/'status.tsv').exists() else {};routed=m.get('resource_stage')=='post_route' and m.get('requested_stage')=='route'
  internal=tsv(job/'internal_timing.tsv') if routed and (job/'internal_timing.tsv').exists() else {};power=m.get('power_post_route_vectorless',{}) if routed else {};checks=parse_timing_checks(job/'timing_post_route.rpt') if routed else {}
  current=json.loads((ROOT/'status.json').read_text()) if (ROOT/'status.json').exists() else {};active=current.get('active_design')==id and current.get('phase')=='IMPLEMENT'
  stage=live.get('stage',m.get('resource_stage','')) if active else m.get('resource_stage','');status='RUNNING' if active else m.get('status','QUEUED')
  if m.get('requested_stage')=='synth' and not active:status='SYNTHESIS_READY'
  report={'post_synthesis':'utilization_post_synth.rpt','placed':'utilization_post_place.rpt','post_route':'utilization_post_route.rpt'}.get(stage,'')
  u=parse_utilization(job/report) if report else {}
  row={'design':id,'status':status,'stage':stage,'part':PART,'threads':THREADS,'target_mhz':TARGET_MHZ,'worst_setup_slack_ns':m.get('worst_setup_slack_ns','') if routed else '', 'worst_hold_slack_ns':m.get('worst_hold_slack_ns','') if routed else '', 'internal_setup_slack_ns':internal.get('internal_setup_slack_ns',''),'internal_hold_slack_ns':internal.get('internal_hold_slack_ns',''),'estimated_internal_setup_fmax_mhz':m.get('estimated_fmax_mhz','') if routed else '', 'dynamic_power_w_vectorless':power.get('dynamic_w',''),'static_power_w_vectorless':power.get('static_w',''),'total_power_w_vectorless':power.get('total_w',''),'power_confidence':power.get('confidence',''),'no_clock_endpoints':checks.get('no_clock',''),'unconstrained_internal_endpoints':checks.get('unconstrained_internal_endpoints','')}
  for k in ['lut_total','lut_logic','lut_memory','ff','dsp','bram36','bram18','uram']:row[k]=u.get(k,'')
  rows.append(row)
 with (ROOT/'results.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
 return rows

def configure_flow():
 flow=ROOT/'flow';flow.mkdir(exist_ok=True)
 for name in ['run_vivado.py','ooc_clock_integration.tcl']:
  shutil.copy2(PACKAGE/'scripts'/name,flow/name)
 original=(PACKAGE/'scripts/vivado_ppa_ooc.tcl').read_text()
 extra='''# Additional diagnostics only; no RTL, constraints or scheduling changes.
puts "PPA_THREAD_CONFIGURATION maxThreads=[get_param general.maxThreads]"
set diagnostic_file [open [file join $OUTDIR internal_timing.tsv] w]
set diagnostic_registers [all_registers]
foreach {label delay} {internal_setup max internal_hold min} {
    if {[catch {
        set paths [get_timing_paths -quiet -from $diagnostic_registers -to $diagnostic_registers -max_paths 1 -delay_type $delay]
        if {[llength $paths]} {puts $diagnostic_file "${label}_slack_ns\\t[get_property SLACK [lindex $paths 0]]"}
        report_timing -from $diagnostic_registers -to $diagnostic_registers -delay_type $delay -max_paths 10 -file [file join $OUTDIR ${label}.rpt]
    } message]} {puts stderr "PPA_DIAGNOSTIC_UNAVAILABLE $label: $message"}
}
if {[llength $data_inputs]} {
    catch {report_timing -from $data_inputs -delay_type min -max_paths 10 -file [file join $OUTDIR input_hold.rpt]}
}
if {[llength [all_outputs]]} {
    catch {report_timing -to [all_outputs] -delay_type min -max_paths 10 -file [file join $OUTDIR output_hold.rpt]}
}
close $diagnostic_file
catch {report_clock_utilization -file [file join $OUTDIR clock_utilization.rpt]}
catch {report_drc -file [file join $OUTDIR drc_post_route.rpt]}
'''
 marker='set setup_paths [get_timing_paths -quiet -max_paths 1 -delay_type max]'
 assert original.count(marker)==1
 updated=original.replace(marker,extra+'\n'+marker)
 assert original.split('set STATUS SYNTH_PASS',1)[0]==updated.split('set STATUS SYNTH_PASS',1)[0]
 (flow/'vivado_ppa_ooc.tcl').write_text(updated)
 write_json(ROOT/'flow_changes.json',{'basis':'copy of supplied PPA flow','changes':'extra internal/boundary timing and clock/DRC reports only','constraints_unchanged':True,'synthesis_prefix_unchanged':True})

def prepare():
 configure_flow();original=json.loads((PACKAGE/'work/plan.json').read_text());lookup={d['id']:d for d in original['designs']};plan=dict(original);plan['designs']=[lookup[id] for id in DESIGNS];write_json(ROOT/'plan.json',plan)
 (ROOT/'rtl').mkdir(exist_ok=True)
 synth_prefix=hashlib.sha256((ROOT/'flow/vivado_ppa_ooc.tcl').read_text().split('set STATUS SYNTH_PASS',1)[0].encode()).hexdigest()
 version=subprocess.check_output([VIVADO,'-version'],text=True).splitlines()[0];checks=[]
 for id in DESIGNS:
  srcroot=origin(id);source_job=srcroot/'results'/PART/id;manifest=srcroot/'rtl'/(id+'.json');m=json.loads((source_job/'metrics.json').read_text());spec=json.loads(manifest.read_text())
  assert m['status']=='SYNTH_PASS' and m['resource_stage']=='post_synthesis' and m['vivado_state']['blackbox_count']=='0',id
  assert m['part']==PART and m['clock_mhz']==TARGET_MHZ and m['vivado_version']==version,id
  assert m['synthesis_flow_sha256']==synth_prefix,id
  assert digest(manifest)==m['input_metadata_sha256'],(id,'metadata changed')
  assert digest(source_job/'post_synth.dcp')==m['synthesis_checkpoint_sha256'],(id,'checkpoint mismatch')
  assert {p:digest(p) for p in spec['sources']}==m['source_sha256']==spec['source_sha256'],(id,'RTL mismatch')
  d=lookup[id]
  if id.startswith('lumixed'):
   assert d['DMA_ID']==8 and d['group_scale_deferred']
   assert m['utilization_post_synthesis']['dsp']==17*d['YS']+2
  dst=ROOT/'results'/PART/id;dst.mkdir(parents=True,exist_ok=True)
  # Retain existing implementation attempts on explicit restart. Never reseed them.
  existing=dst/'metrics.json'
  if not existing.exists():
   for name in ['post_synth.dcp','metrics.json','utilization_post_synth.rpt','primitive_counts_post_synthesis.tsv','primitive_counts.tsv','timing_post_synth_PRELIMINARY.rpt','power_post_synth_PRELIMINARY.rpt','input_metadata.json']:
    p=source_job/name
    if p.exists():shutil.copy2(p,dst/name)
   shutil.copy2(source_job/'metrics.json',dst/'original_synthesis_metrics.json')
   shutil.copy2(source_job/'vivado.log',dst/'vivado_synth.log')
  shutil.copy2(manifest,ROOT/'rtl'/manifest.name)
  checks.append({'id':id,'origin':str(source_job),'checkpoint_sha256':m['synthesis_checkpoint_sha256'],'dsp':m['utilization_post_synthesis']['dsp'],'source_revision': '62b02896 (updated mixed-width scaler)' if id.startswith('lumixed') else '6bffd774 (verified FP32-W8 Gemmini port)','verified':True})
 write_json(ROOT/'checkpoint_preflight.json',checks)
 (ROOT/'README.md').write_text('''# Updated scaled LUMIXED and Edited Gemmini implementation

Six designs, one Vivado process at a time, up to eight CPU threads, reduced priority.
Same U250 part and 50-MHz target as the previous comparison. Four LUMIXED designs
use the verified updated-scaler ID8 synthesis checkpoints (36/70 DSP); Gemmini
4x4 and8x8 use their verified FP32-W8 synthesis checkpoints (SP32/ACC4,
16 source slots per independent read/write pool). No fresh synthesis or RTL
changes are authorized by this runner. All checkpoints, manifests and RTL hashes
are checked before reuse. Source synthesis results stay unchanged.

Outputs: results.csv, status.json, checkpoint_preflight.json, original command logs,
per-design placed/routed DCPs, utilization, setup/hold, internal/boundary path reports,
clock/DRC reports and vectorless dynamic/static/total power. Raw reports remain
under results/xcu250-figd2104-2-e/<design>/. No bitstreams are generated.

The previous zero-delay synchronous OOC data-I/O assumptions are preserved for
comparability. A common internal BUFGCE is added outside each accelerator.
Internal setup/hold is reported separately from I/O timing. An estimated internal
setup Fmax is not a validated system clock; full timing closure requires setup
AND hold and a constrained design. Vectorless power assumes the50-MHz target;
it is not workload-measured power or verified inference energy. FPGA static
power is reported separately. Missing or failed results remain explicit.

Run/status/stop from any directory:

```bash
python3 /home/kioannou/artifacts/lumixed_gemmini_implementation_8cores_20261124/run_implementation.py start
python3 /home/kioannou/artifacts/lumixed_gemmini_implementation_8cores_20261124/run_implementation.py status
python3 /home/kioannou/artifacts/lumixed_gemmini_implementation_8cores_20261124/run_implementation.py stop
```

The start command detaches the worker; SSH/Codex disconnection does not terminate
it. Failures preserve synthesis and partial implementation reports and do not
prevent attempting later designs. Completed matching route results can be reused
on explicit restart. Existing older PPA evidence is never overwritten.
''')

def worker():
 os.chdir(ROOT);lock=(ROOT/'worker.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 cpus=sorted(os.sched_getaffinity(0))[:THREADS];assert len(cpus)==THREADS;os.sched_setaffinity(0,cpus);os.nice(10)
 os.environ['OMP_NUM_THREADS']=str(THREADS);os.environ['PPA_MAX_THREADS']=str(THREADS)
 try:
  state('PREFLIGHT',cpu_affinity=cpus);prepare();status_table()
  for index,id in enumerate(DESIGNS):
   state('IMPLEMENT',active_design=id,completed_attempts=index,cpu_affinity=cpus)
   cmd=[sys.executable,'-u',str(ROOT/'flow/run_vivado.py'),'--plan',str(ROOT/'plan.json'),'--rtl-dir',str(ROOT/'rtl'),'--out',str(ROOT/'results'),'--vivado',VIVADO,'--part',PART,'--clock-mhz',str(TARGET_MHZ),'--stage','route','--max-threads',str(THREADS),'--select',id]
   write_json(ROOT/(id+'.command.json'),cmd)
   with (ROOT/(id+'.runner.log')).open('a') as f:proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
   job=ROOT/'results'/PART/id;metrics=json.loads((job/'metrics.json').read_text());log=(job/'vivado.log').read_text(errors='replace')
   assert 'VIVADO_PPA_REUSED_MATCHING_SYNTH_CHECKPOINT' in log,(id,'expected checkpoint reuse not confirmed')
   state('ATTEMPT_COMPLETE',last_design=id,last_status=metrics.get('status'),exit_code=proc.returncode,completed_attempts=index+1,cpu_affinity=cpus);status_table()
  rows=status_table();state('COMPLETE',completed_attempts=len(DESIGNS),routed=sum(r['stage']=='post_route' for r in rows),statuses={r['design']:r['status'] for r in rows},cpu_affinity=cpus)
 except Exception as e:
  state('FAILED',error=str(e),cpu_affinity=cpus);traceback.print_exc()
  try:status_table()
  except Exception:pass
  raise

def alive(pid):
 try:os.kill(pid,0);return Path(f'/proc/{pid}/stat').read_text().split()[2]!='Z'
 except (ProcessLookupError,FileNotFoundError):return False

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('action',choices=['start','status','stop','worker']);args=a.parse_args();ROOT.mkdir(exist_ok=True)
 if args.action=='worker':worker();return
 guard=(ROOT/'start.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX)
 p=ROOT/'worker.pid';pid=int(p.read_text()) if p.exists() else None
 if args.action=='start':
  if pid and alive(pid):print('Already active, PID',pid);return
  with (ROOT/'runner.log').open('a') as f:proc=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  p.write_text(str(proc.pid)+'\n');print('Started detached implementation worker PID',proc.pid);print('Log:',ROOT/'runner.log');return
 if args.action=='status':
  print('Worker:', 'active' if pid and alive(pid) else 'inactive','PID:',pid)
  if (ROOT/'status.json').exists():print((ROOT/'status.json').read_text())
  if (ROOT/'results.csv').exists():print((ROOT/'results.csv').read_text())
  return
 if pid and alive(pid):
  cmd=Path(f'/proc/{pid}/cmdline').read_bytes();assert str(Path(__file__).resolve()).encode() in cmd and b'worker' in cmd;assert os.getpgid(pid)==pid
  os.killpg(pid,signal.SIGTERM);write_json(ROOT/'status.json',dict(phase='STOPPED_BY_USER',updated=now(),pid=pid));print('Stopped implementation process group',pid)
 else:print('Worker is not active')

if __name__=='__main__':main()
