#!/usr/bin/env python3
"""Sequential, failure-tolerant Vivado sweep over already elaborated RTL.

Precondition: work/rtl/<design-id>.json with top, clock_port, sources, include_dirs.
This script NEVER invents RTL or Vivado PPA metrics.
"""
import argparse
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
    return h.hexdigest()

def timestamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def tsv(path):
    if not path.exists():return {}
    result={}
    for l in path.read_text(errors='replace').splitlines():
        pair=l.split('\t',1)
        if len(pair)==2:result[pair[0]]=pair[1]
    return result

def parse_power(path):
    """Extract Vivado report_power summary fields, never silently mix static with dynamic."""
    if not path.exists():return {}
    s=path.read_text(errors='replace')
    out={}
    patterns={
        'total_w':r'(?im)^\s*[|]?\s*Total On-Chip Power(?: \(W\))?\s*[|:]\s*([0-9.]+)',
        'dynamic_w':r'(?im)^\s*[|]?\s*Dynamic(?: \(W\))?\s*[|:]\s*([0-9.]+)',
        'static_w':r'(?im)^\s*[|]?\s*Device Static(?: \(W\))?\s*[|:]\s*([0-9.]+)',
    }
    for key,regex in patterns.items():
        match=re.search(regex,s)
        if match:out[key]=float(match.group(1))
    confidence=re.search(r'(?im)\bConfidence Level\s*[|:]\s*(Low|Medium|High)',s)
    if confidence:out['confidence']=confidence.group(1)
    return out

def parse_counts(path):
    if not path.exists():return {}
    out={}
    for row in csv.reader(path.open(),delimiter='\t'):
        if len(row)==2 and row[0]!='category':
            try:out[row[0].lower()]=int(row[1])
            except ValueError:pass
    return out

def parse_utilization(path):
    """Authoritative Vivado table accounting (logic LUTs and LUTRAM separate)."""
    if not path.exists():return {}
    aliases={'CLB LUTs':'lut_total','Slice LUTs':'lut_total','LUT as Logic':'lut_logic','LUT as Memory':'lut_memory','LUT as Distributed RAM':'lut_distributed','LUT as Shift Register':'lut_srl','CLB Registers':'registers_total','Slice Registers':'registers_total','Register as Flip Flop':'ff','Register as Latch':'latches','DSPs':'dsp','DSP48E2':'dsp','Block RAM Tile':'bram_tiles','RAMB36/FIFO':'bram36','RAMB18':'bram18','URAM':'uram'}
    result={}
    for line in path.read_text(errors='replace').splitlines():
        if not line.lstrip().startswith('|'):continue
        cols=[v.strip() for v in line.split('|')]
        if len(cols)<3:continue
        name=cols[1].replace('*','').strip();key=aliases.get(name)
        if not key:continue
        try:value=float(cols[2].replace(',',''))
        except ValueError:continue
        result.setdefault(key,int(value) if value.is_integer() else value)
    if all(k in result for k in ['bram18','bram36','uram']):result['mapped_ram_mibits']=(result['bram18']*18+result['bram36']*36+result['uram']*288)/1024
    return result

def parse_timing_checks(path):
    if not path.exists():return {}
    text=path.read_text(errors='replace');out={}
    for key in ('no_clock','unconstrained_internal_endpoints','constant_clock','multiple_clock','loops'):
        found=re.search(r'checking\s+'+key+r'\s*\((\d+)\)',text,re.I)
        if found:out[key]=int(found.group(1))
    return out

def safe_part(part):return re.sub(r'[^a-zA-Z0-9_.-]+','_',part)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--plan',type=Path,default=Path('work/plan.json'))
    ap.add_argument('--rtl-dir',type=Path,default=Path('work/rtl'))
    ap.add_argument('--out',type=Path,default=Path('work/results'))
    ap.add_argument('--vivado',default='vivado')
    ap.add_argument('--part',required=True,help='Exact Vivado part returned by scripts/discover_parts.tcl')
    ap.add_argument('--clock-mhz',type=float,default=50.0)
    ap.add_argument('--stage',choices=('synth','route'),default='synth')
    ap.add_argument('--select',nargs='*',help='Optional exact design IDs')
    ap.add_argument('--limit',type=int)
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--force',action='store_true')
    ap.add_argument('--max-threads',type=int,default=2)
    ap.add_argument('--timeout-hours',type=float,default=0,help='0 disables time limit; otherwise mark timed-out jobs without fabricating metrics')
    args=ap.parse_args()
    if args.clock_mhz<=0:ap.error('clock-mhz must be positive')
    plan=json.loads(args.plan.read_text())
    designs=plan['designs']
    if args.select:
        unknown=set(args.select)-{d['id'] for d in designs}
        if unknown:ap.error('Unknown design IDs: '+','.join(sorted(unknown)))
        designs=[d for d in designs if d['id'] in args.select]
    if args.limit is not None:designs=designs[:args.limit]
    partdir=args.out/safe_part(args.part)
    partdir.mkdir(parents=True,exist_ok=True)
    vivado=shutil.which(args.vivado) if '/' not in args.vivado else args.vivado
    script=Path(__file__).resolve().with_name('vivado_ppa_ooc.tcl')
    if not script.is_file():raise SystemExit('Missing bundled vivado_ppa_ooc.tcl')
    helper=script.with_name('ooc_clock_integration.tcl')
    flow_sources={p.name:sha(p) for p in (script,helper)}
    flow_sha=hashlib.sha256(json.dumps(flow_sources,sort_keys=True).encode()).hexdigest()
    synthesis_flow_sha=hashlib.sha256(script.read_text().split('set STATUS SYNTH_PASS',1)[0].encode()).hexdigest()
    vivado_version=''
    if vivado and not args.dry_run:
        try:
            version=subprocess.run([str(vivado),'-version'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30,check=False,text=True)
            vivado_version=version.stdout.splitlines()[0] if version.stdout else 'UNKNOWN_VERSION'
        except (OSError,subprocess.TimeoutExpired):vivado_version='UNKNOWN_VERSION'
    summary=[]
    for d in designs:
        id=d['id'];job=partdir/id
        metadata=args.rtl_dir/(id+'.json')
        record={'id':id,'part':args.part,'requested_stage':args.stage,'clock_mhz':args.clock_mhz,'updated':timestamp(),
                'vivado_version':vivado_version,'ppa_tcl_sha256':flow_sha,'synthesis_flow_sha256':synthesis_flow_sha,
                'flow_source_sha256':flow_sources}
        if not metadata.is_file():
            record.update(status='BLOCKED_RTL',error='Missing '+str(metadata))
            summary.append(record);print('BLOCKED_RTL',id);continue
        try:
            spec=json.loads(metadata.read_text())
            if spec.get('synthesis_scope')!='OOC':raise ValueError('Expected explicit synthesis_scope=OOC')
            for key in ('top','clock_port'):
                if not spec.get(key):raise ValueError('Missing '+key)
            src=[str(Path(s).resolve()) for s in spec['sources']]
            inc=[str(Path(s).resolve()) for s in spec.get('include_dirs',[])]
            if not src or any(not Path(s).is_file() for s in src):raise ValueError('Missing one or more real RTL source files')
            if any(not Path(s).is_dir() for s in inc):raise ValueError('Missing one or more include directories')
            checks={s:sha(s) for s in src}
            expected=spec.get('source_sha256',{})
            if expected and expected!=checks:raise ValueError('RTL source SHA256 mismatch; regenerate manifest')
            record.update(top=spec['top'],clock_port=spec['clock_port'],source_sha256=checks,
                          input_metadata_sha256=sha(metadata))
        except Exception as e:
            record.update(status='INVALID_RTL_INPUT',error=str(e))
            summary.append(record);print('INVALID_RTL_INPUT',id,str(e));continue
        job.mkdir(parents=True,exist_ok=True)
        write_json(job/'input_metadata.json',spec)
        (job/'sources.txt').write_text('\n'.join(src)+'\n')
        (job/'incdirs.txt').write_text('\n'.join(inc)+'\n')
        cmd=[str(vivado or args.vivado),'-mode','batch','-nojournal','-nolog','-source',str(script),
             '-tclargs',spec['top'],str((job/'sources.txt').resolve()),
             str((job/'incdirs.txt').resolve()),args.part,spec['clock_port'],
             f'{1000/args.clock_mhz:.6f}',args.stage,str(job.resolve())]
        write_json(job/'command.json',cmd)
        prior=job/'metrics.json'
        reuse_synth=False
        if prior.exists():
            prev=json.loads(prior.read_text())
            reuse_synth=args.stage in ('synth','route') and (job/'post_synth.dcp').exists() and all(prev.get(k)==record.get(k) for k in ['source_sha256','part','clock_mhz','synthesis_flow_sha256','vivado_version','input_metadata_sha256'])
            if reuse_synth:
                reuse_synth=bool(prev.get('synthesis_checkpoint_sha256')) and prev['synthesis_checkpoint_sha256']==sha(job/'post_synth.dcp')
            # Changes after the synthesis phase do not invalidate accelerator-only
            # synthesis. Require the preserved report, clock check and checkpoint.
            if args.stage=='synth' and reuse_synth and prev.get('vivado_state',{}).get('blackbox_count')=='0' and prev.get('vivado_state',{}).get('clock_found')=='1' and parse_utilization(job/'utilization_post_synth.rpt'):
                summary.append(prev);print('REUSED_SYNTHESIS',id,prev.get('status'));continue
            if reuse_synth:
                write_json(job/'metrics_synthesis_preserved.json',prev)
                if (job/'vivado.log').exists() and not (job/'vivado_synth.log').exists():shutil.copy2(job/'vivado.log',job/'vivado_synth.log')
        if prior.exists() and not args.force and not args.dry_run:
            old=json.loads(prior.read_text())
            if old.get('source_sha256')==record['source_sha256'] and old.get('part')==args.part and old.get('requested_stage')==args.stage and old.get('clock_mhz')==args.clock_mhz and old.get('ppa_tcl_sha256')==flow_sha and old.get('vivado_version')==vivado_version and old.get('input_metadata_sha256')==record['input_metadata_sha256'] and old.get('status') in ('SYNTH_PASS','ROUTED_TIMING_PASS','ROUTED_TIMING_FAIL','ROUTED_TIMING_UNVERIFIED'):
                summary.append(old);print('REUSED',id,old['status']);continue
        if args.dry_run:
            record.update(status='DRY_RUN',command=cmd)
            summary.append(record);print('DRY_RUN',id);continue
        if vivado is None or not Path(vivado).is_file():
            record.update(status='NO_VIVADO',error='Cannot find Vivado executable: '+args.vivado)
            summary.append(record);print('NO_VIVADO',id);continue
        env=os.environ.copy()
        # Keep the exact evaluation scripts beside each attempt for replay.
        flow_dir=job/'flow_sources'/flow_sha
        flow_dir.mkdir(parents=True,exist_ok=True)
        for flow_source in (script,helper):shutil.copy2(flow_source,flow_dir/flow_source.name)
        # Execute the immutable snapshot whose digest is recorded, even if the
        # integration script is subsequently improved for a different attempt.
        cmd[cmd.index('-source')+1]=str((flow_dir/script.name).resolve())
        write_json(job/'command.json',cmd)
        env['OMP_NUM_THREADS']=str(args.max_threads)
        env['PPA_MAX_THREADS']=str(args.max_threads)
        if reuse_synth:env['PPA_REUSE_SYNTH']='1'
        else:env.pop('PPA_REUSE_SYNTH',None)
        log=job/'vivado.log'
        with log.open('w') as f:
            try:
                proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,check=False,
                                    timeout=args.timeout_hours*3600 if args.timeout_hours>0 else None)
                retcode=proc.returncode
            except subprocess.TimeoutExpired:
                retcode=124
                f.write('\nVIVADO_PPA_TIMEOUT\n')
        state=tsv(job/'status.tsv')
        status=state.get('status','VIVADO_CRASH' if retcode else 'MISSING_STATUS')
        if retcode and state.get('stage')=='post_synthesis' and status=='SYNTH_PASS':status='POST_SYNTH_FLOW_FAIL'
        if retcode==124:status='TIMED_OUT' # Check reports to distinguish partial stages
        record.update(status=status,exit_code=retcode,vivado_state=state,
                      resource_stage=state.get('stage','none'),
                      resource_counts=parse_counts(job/'primitive_counts.tsv'),
                      power_post_synth_preliminary=parse_power(job/'power_post_synth_PRELIMINARY.rpt'),
                      power_post_route_vectorless=parse_power(job/'power_post_route_vectorless.rpt'))
        record['utilization_post_synthesis']=parse_utilization(job/'utilization_post_synth.rpt')
        chosen={'post_synthesis':'utilization_post_synth.rpt','placed':'utilization_post_place.rpt','post_route':'utilization_post_route.rpt'}.get(record['resource_stage'],'')
        record['utilization_authoritative']=parse_utilization(job/chosen) if chosen else {}
        record['synthesis_resource_counts']=parse_counts(job/'primitive_counts_post_synthesis.tsv')
        record['synthesis_checkpoint_sha256']=sha(job/'post_synth.dcp') if (job/'post_synth.dcp').exists() else None
        record['post_route_checkpoint_sha256']=sha(job/'post_route.dcp') if (job/'post_route.dcp').exists() else None
        for name in ('worst_setup_slack_ns','worst_hold_slack_ns','estimated_fmax_mhz'):
            val=state.get(name,'')
            record[name]=float(val) if val not in ('',None) else None
        write_json(job/'metrics.json',record)
        summary.append(record);print(status,id)
    write_json(partdir/'sweep_summary.json',summary)
    cols=('id','status','part','requested_stage','clock_mhz','resource_stage','worst_setup_slack_ns',
          'worst_hold_slack_ns','estimated_fmax_mhz','error')
    with (partdir/'sweep_summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(summary)
    print('Summary:',partdir/'sweep_summary.csv')
    if any(x['status'] in ('BLOCKED_RTL','INVALID_RTL_INPUT','NO_VIVADO','VIVADO_CRASH','SYNTH_FAIL') for x in summary):
        print('WARNING: Some designs are incomplete. See statuses; no metrics have been invented.')
if __name__=='__main__':main()
