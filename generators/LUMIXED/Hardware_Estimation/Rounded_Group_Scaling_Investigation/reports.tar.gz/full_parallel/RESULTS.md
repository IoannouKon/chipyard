# Rounded group-wise scaling: actual comparison

Experimental branch: experiment/rounded-group-scaling; base d8946796bc63859626bd8713df6aaa84b9ed4d49. No production changes, commits, pushes or merges.

| Design | Checks PASS | Larger cycles | Δ cycles vs exact | LUT | FF | DSP | BRAM36/18 | URAM | Synth-est. MHz | Max relative L2 |
|---|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| off_exact | 23/23 | 3307637 | 0% | 115568 | 11313 | 0 | 80/0 | 40 | 85.78536501672815 | 0 |
| off_rounded | 23/23 | 3307707 | 0.002116% | 123962 | 10403 | 0 | 96/0 | 0 | 79.4407372100413 | 2.74e-07 |
| on_exact | 23/23 | 3391365 | 0% | 164287 | 25134 | 70 | 209/0 | 40 | 81.83975775431703 | 0 |
| on_a | 23/23 | 3391365 | 0% | 164985 | 21480 | 70 | 225/0 | 0 | 55.154155865644476 | 2.332e-07 |
| on_b | 23/23 | 3391365 | 0% | 161098 | 21455 | 10 | 225/0 | 0 | 78.43752451172642 | 2.321e-07 |

| Design | Synth dynamic W | Synth static W | Synth total W | Internal setup ns | Internal hold ns |
|---|---:|---:|---:|---:|---:|
| off_exact | 0.47 | 2.957 | 3.427 | 8.343 | 0.053 |
| off_rounded | 0.41 | 2.953 | 3.363 | 7.412 | 0.053 |
| on_exact | 0.569 | 2.96 | 3.529 | 7.781 | 0.053 |
| on_a | 0.548 | 2.956 | 3.504 | 1.869 | 0.053 |
| on_b | 0.479 | 2.955 | 3.433 | 7.251 | 0.053 |

## What the measurements mean

The cycle sum covers six full synthetic Qwen3-shaped GEMMs: R4/K1024/N1024 and R4/K1024/N3072 for W8/W4/W2. It is not 196 projections or end-to-end inference. Geometry/capacities: B8/RF4/YS4/ID8, Rmax4/Kmax3072/Nmax3072, beat8, buffers2, GROUP_SCALE_YS4, all optional sparsity/burst/grouping optimizations OFF. Group sizes32/64/128 are exercised in smoke tests; larger tests use128.

All input and quantized-weight hashes must match between exact/rounded counterparts. Synthetic FP32 normals span bounded exponents; explicit ties, cancellation, subnormal, overflow, inactive-row and multi-window tests are separate. Quantization error is excluded from the exact-versus-rounded comparison. No claim about model inference quality is supported.

Own-reference verification is bit-exact, including RNE and true fused rounding. For scaled rounding, the independent integer reference recalculates fragment sums from inputs and validates per-bank FIFO coverage against theoretical K-window/bank/group partitions. Observed retirement metadata establishes accumulation order; no DUT arithmetic results are used as expected values. This is not an independently predicted arbitration schedule.

Option A uses exact fixed-point scaling, then RNE per bank fragment, then FP32 RNE adds. Option B rounds the bank fragment, widens FP16 scales exactly with HardFloat RecFNToRecFN (including signed zero/subnormals), and uses MulAddRecFN with one final rounding of product-plus-sum. The explicit FP16 widening exposes low zero significand bits to synthesis; inferred resource reductions must be read from actual reports. Wide ExactScaleMultiplier modules must be absent from B’s accelerator module closure.

SRAM forwarding carries the completed FP32 add/FMA result to consecutive same-column updates. The existing group-engine output register and synchronous accumulator read are aligned by the same valid/tag/first descriptor; the controller drains the engine and pending write before K-window changes and storage. FMA is combinational at the feedback point; critical path can worsen despite unchanged cycle latency.

GROUP_SCALE_YS batching remains functional. B emits tagged row batches and instantiates GROUP_SCALE_YS FMA lanes; one row per lane may update per cycle. Initialization descriptors clear all active rows without using an FMA lane. The engine FIFO schedule and batch acceptance remain unchanged. Reduced-sharing variants still require separate functional and resource evidence.

Vivado2023.2, U250 xcu250-figd2104-2-e, accelerator-only OOC synthesis, 20ns clock, identical constraints/settings for all modes. No placement/routing. Synthesis timing, ideal-boundary hold and vectorless power are preliminary; they are not achieved frequency, routed power or measured energy. Core-retention guard rejects unresolved black boxes and missing arithmetic/RAM. Resource hierarchy and worst internal timing paths are archived for attribution.

Scaling/FIFO stalls are simulation observations, not new performance counters: FIFO-backpressure cycles and READ_ON cycles with exhausted scale credits. Existing load_w and select counters overlap; total=load_x+generate_brams+load_w_and_select+store_o. No duplicate counting.

## Assessment from completed primary runs

Option A: LUT reduction -0.4249%, FF reduction 14.54%, DSP reduction 0%; cycle delta 0%.
Option B: LUT reduction 1.941%, FF reduction 14.64%, DSP reduction 85.71%; cycle delta 0%.
Numerical error and internal synthesis paths must be assessed together. A smaller DSP count alone does not establish a preferred implementation; routed timing/power and the intended numerical tolerance remain future gates.

Provisional experimental preference: Option B. This rule requires max relative L2 <1e-4 and aggregate cycle delta <5%; it selects B only when measured DSP cost is lower, LUT cost is within 10% of A and synthesis-estimated frequency is within 10% of A. These are stated engineering screening criteria, not an LLM-quality tolerance or a production acceptance standard. No merge is recommended before review and routed timing/power validation.

## Reproduce and evidence

Run `python3 compile.py` after source changes; `python3 investigate.py start` resumes cached completed phases. `python3 finalize.py` regenerates this summary. Use a fresh case directory when changing arithmetic/configuration: completed result hashes alone do not authorize reusing stale builds.

Source: implementation_source/, implementation.patch, source_hashes.json. References: reference.py, vector_reference.py. Logs and per-test inputs, outputs, expected bits, traces and hashes: cases/<mode>/verification/. Cycles and accuracy: per-case cycles_accuracy.csv plus cycle_accuracy_comparison.csv. Synthesis: cases/<mode>/synthesis/, including hierarchical utilization, primitive counts, critical paths, preliminary power, and exact Tcl/commands. All writable outputs/temp/caches stay on /var/tmp. Original /home tool caches are read-only.
