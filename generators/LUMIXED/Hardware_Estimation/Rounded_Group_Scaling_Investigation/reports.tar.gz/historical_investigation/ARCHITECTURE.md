# Experimental arithmetic contracts

This is isolated experimental RTL, not a production update. Mode selection is at elaboration; RoCC commands, weight packing, scale layout and DMA are unchanged. GROUP_SCALE_ROUNDING=0 is the original behavior; 1 selects A, 2 selects B and both require ROUNDED_ACCUMULATION=true with FP32 group scaling enabled. Existing unscaled rounded mode keeps GROUP_SCALE_ROUNDING=0 and its verified subtotal register.

Primary geometry: B8/RF4/YS4/ID8; Rmax4/Kmax3072/Nmax3072; full-parallel GROUP_SCALE_YS4. FP32 fragment fixed-point width is 285+ceil(log2(3072))=297 bits, with 149 fractional bits. Exact scaled accumulator width is 325+12=337 bits, with 173 fractional bits. The exact FP16 scale has a signed 12-bit significand and exponent alignment; ExactScaleMultiplier preserves the full 309-bit product before alignment into the 337-bit accumulator units.

- OFF exact: exact products and bank reduction, exact 297-bit running sum, one final FP32 RNE.
- OFF rounded: exact bank subtotal -> FP32 RNE -> existing subtotal register -> FP32 RNE add -> 32-bit sum.
- ON exact: exact bank fragments -> exact FP16 scaling/alignment -> exact 337-bit running sum -> one final FP32 RNE.
- ON A: exact bank fragments -> same exact scaling/alignment -> FP32 RNE -> registered fragment -> FP32 RNE add -> 32-bit sum.
- ON B: exact bank fragments -> FP32 RNE -> registered fragment, plus exact FP16-to-FP32 widening -> FP32 fused multiply-add with previous sum -> 32-bit sum. Multiplication and addition have one combined final rounding, not two.

OutputAccumulator retains its three status bits per stored word. Logical output storage therefore changes from 337+3=340 bits per word in ON exact to 32+3=35 bits in A/B: 4,177,920 -> 430,080 bits at these capacities (89.7% logical reduction). This does not predict physical BRAM/URAM counts: banking, port geometry and inference remain measured. Scale SRAM, product tables and activation SRAM are unchanged.

The SRAM read launches on groupEngine.out.valid. Its tag, first descriptor, data, FP32 scale and row mask are registered together for the next-cycle update. OutputAccumulator's previousWords bypass forwards a completed FP32 add/FMA for a consecutive same-column update. The FMA is combinational in that feedback cycle: it may have a long setup path, to be measured. No claim of extra throughput is made without counters.

For shared scalers, the old selected.ready/batch/lastBatch FIFO schedule is retained. A and exact modes retire the complete row vector after its final batch. B retires row batches with matching row masks and owns one physical FMA per GROUP_SCALE_YS lane. It asserts that no two active rows use the same FMA lane in a cycle. Initialization descriptors bypass FMA and clear active outputs to positive zero; this avoids multiplying zero by an uninitialized scale. Inactive rows are masked. Engine empty plus pending SRAM update must drain before a K-window transition or output storage.

HardFloat RecFNToRecFN widens FP16 scales exactly, including signed zero and subnormals. Its structural mantissa widening exposes 13 trailing zero FP32 significand bits to synthesis. Whether that lowers the inferred FMA DSP cost is a measurement question; no manually redesigned multiplier is introduced.

The independent reference uses arbitrary-size integer products/sums and explicit IEEE FP32 RNE, with integer-exact single-round FMA. It observes FIFO metadata only to establish the actual association order, validates every per-bank fragment against the K-window/bank/group partition and recomputes all numeric contributions from original inputs. It never treats DUT subtotals as expected values. The FMA reference additionally matches 10,000 independently computed libm.fmaf cases.

Regular data are bounded, synthetic FP32 activations and signed quantized weights; they are not captured Qwen tensors. Literal RNE ties and fused cancellation, signed scales/weights, underflow/overflow, inactive rows, output guards, forwarding, random command/memory/response backpressure and multiple K windows are separate gates. Accuracy relative to the exact counterpart isolates accumulation error on the same quantized data; it does not measure quantization error or inference quality.
