#!/usr/bin/env python3
"""Isolated, resumable five-mode RTL/Verilator/U250 synthesis investigation."""
from pathlib import Path
import sys,os,json,time,subprocess,hashlib,shutil,zipfile,signal,fcntl,re,csv,struct,importlib.util,traceback,math
sys.dont_write_bytecode=True
E=Path(__file__).resolve().parent;W=E.parent/'worktree';TOOLS=Path('/home/kioannou/chipyard_1.13.0/.conda-env');OLD=Path('/home/kioannou/artifacts/lumixed_pipelined_rounded_id8_sweep_20261126');SCALA=W/'generators/LUMIXED/src/main/scala';CHILD=None;MODE=None
MODES=['off_exact','off_rounded','on_exact','on_a','on_b'];MEMSIZE=16777216;OUT=0xf00008;B=8;RF=4;YS=4
ENV=os.environ.copy();ENV.update(HOME=str(E/'java-home'),TMPDIR=str(E/'tmp'),TMP=str(E/'tmp'),TEMP=str(E/'tmp'),XDG_CACHE_HOME=str(E/'xdg'),COURSIER_CACHE=str(E/'coursier'),CHISEL_FIRTOOL_PATH='/home/kioannou/.local/opt/firtool-1.75.0/bin',PATH='/home/kioannou/.local/opt/firtool-1.75.0/bin:'+str(TOOLS/'bin')+':'+str(TOOLS/'riscv-tools/bin')+':'+ENV['PATH'],LD_LIBRARY_PATH=str(TOOLS/'lib'),RISCV=str(TOOLS/'riscv-tools'),JAVA_TOOL_OPTIONS=f'-Xmx4G -Xss8M -XX:ActiveProcessorCount=4 -Djava.io.tmpdir={E}/tmp -Duser.home={E}/java-home',MAKEFLAGS='-j4',CXX=str(TOOLS/'bin/x86_64-conda-linux-gnu-g++'),CC=str(TOOLS/'bin/x86_64-conda-linux-gnu-gcc'),PPA_MAX_THREADS='4',PPA_REUSE_SYNTH='0')
def save(p,obj):p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state(phase,**kw):
 obj=dict(phase=phase,mode=MODE,pid=os.getpid(),time=time.strftime('%Y-%m-%dT%H:%M:%S%z'),cpus=sorted(os.sched_getaffinity(0)),**kw);save(E/'status.json',obj);print(obj,flush=True)
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
REF=load('reference',E/'reference.py');PARSE=load('ppa',E/'scripts/report_parsers.py')
def run(cmd,log,phase,timeout=1800,env=ENV,cwd=E):
 global CHILD
 assert shutil.disk_usage(E).free>10*1024**3,'Disk guard'
 cmd=list(map(str,cmd));save(log.with_suffix('.command.json'),dict(command=cmd,cwd=str(cwd),timeout=timeout,cpus=sorted(os.sched_getaffinity(0)),env_overrides={k:env[k] for k in ['HOME','TMPDIR','JAVA_TOOL_OPTIONS','PPA_MAX_THREADS'] if k in env}))
 log.parent.mkdir(parents=True,exist_ok=True)
 with log.open('w') as f:
  CHILD=subprocess.Popen(cmd,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);state(phase,child_pid=CHILD.pid,log=str(log))
  try:code=CHILD.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(CHILD.pid,signal.SIGTERM)
   try:CHILD.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(CHILD.pid,signal.SIGKILL);CHILD.wait()
   CHILD=None;raise RuntimeError('TIMEOUT '+str(log))
  CHILD=None
 if code:raise RuntimeError('EXIT '+str(code)+' '+str(log)+'\n'+log.read_text(errors='replace')[-2500:])
def stop(sig,frame):
 if CHILD and CHILD.poll() is None:os.killpg(CHILD.pid,signal.SIGTERM)
 state('STOPPED',signal=sig);raise SystemExit(128+sig)
for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,stop)
def config(mode,scaleRows=4):return dict(B=8,RF=4,YS=4,DMA_ID=8,DMA_Bytes=8,W_BUFFS=2,Rin=4,Cin=3072,Cout=3072,FP_BITS=32,ROUNDED_ACCUMULATION=mode in ['off_rounded','on_a','on_b'],GROUP_SCALE_DEFERRED=mode.startswith('on_'),GROUP_SCALE_ALIGNED=False,GROUP_SCALE_ROUNDING={'on_a':1,'on_b':2}.get(mode,0),GROUP_SCALE_YS=scaleRows,DEBUG=True)
def emit(mode):
 d=E/'cases'/mode;d.mkdir(parents=True,exist_ok=True);cfg=config(mode);save(d/'configuration.json',cfg)
 if (d/'emit_complete.json').exists():return json.loads((d/'rtl'/(mode+'.json')).read_text())
 overlay=d/'overlays'/mode;overlay.mkdir(parents=True,exist_ok=True);cls='ExperimentalScalingConfig'
 args=','.join(f'{k}={str(v).lower() if isinstance(v,bool) else v}' for k,v in dict(Rin=4,Cin=3072,Cout=3072,banks_per_row=8,table_capacity_factor=4,parallel_rows=4,FP_ACTIVATIONS=True,FP_BITS=32,WBitWidth=8,OutBitWidth=32,DMA_Bytes=8,Dma_Ids=8,W_BUFFS=2,ROUNDED_ACCUMULATION=cfg['ROUNDED_ACCUMULATION'],GROUP_SCALE_ALIGNED=False,GROUP_SCALE_DEFERRED=cfg['GROUP_SCALE_DEFERRED'],GROUP_SCALE_ROUNDING=cfg['GROUP_SCALE_ROUNDING'],GROUP_SCALE_YS=4,DEBUG=True,SKIP_ZERO_WEIGHTS=False,FLEXIBLE_BANK_GROUPING=False,WEIGHT_DMA_BURSTS=False,EARLY_WEIGHT_BUFFER_RELEASE=False).items())
 (overlay/(cls+'.scala')).write_text('package ppa\nimport org.chipsalliance.cde.config.Config\nclass '+cls+' extends Config(new Config((site,here,up)=>{case LUMIXED_PACKAGE.LUMIXEDParamsKey => LUMIXED_PACKAGE.LUMIXED_Config.LUMIXED_Config.copy('+args+')}) ++ new chipyard.LUMIXEDRocketConfig)\n');save(overlay/'overlay.json',dict(config_class=cls,package='ppa'));save(d/'plan.json',dict(designs=[dict(id=mode,accelerator='LUMIXED',**cfg)]))
 run([sys.executable,E/'scripts/elaborate_rtl.py','--repo',W,'--plan',d/'plan.json','--overlays',d/'overlays','--out',d/'elaboration','--rtl-dir',d/'rtl','--jar',E/'toolchain/experimental.jar','--tapeout',E/'toolchain/tapeout.jar','--tools-prefix',TOOLS],d/'elaboration.log','ELABORATE',timeout=1800)
 run([sys.executable,E/'scripts/review_rtl.py','--plan',d/'plan.json','--rtl-dir',d/'rtl'],d/'review.log','REVIEW_RTL',timeout=120)
 m=json.loads((d/'rtl'/(mode+'.json')).read_text());sources=[Path(x) for x in m['sources']];has_engine=any(x.name=='GroupScaleEngine.sv' for x in sources);assert has_engine==mode.startswith('on_')
 if mode=='on_b':assert not any(x.name.startswith('ExactScaleMultiplier') for x in sources),'Wide multiplier remains in B'
 save(d/'emit_complete.json',dict(source_count=len(sources),config=cfg));return m

def build(mode,m):
 d=E/'cases'/mode;exe=d/'verilator/VRegisteredContext'
 if (d/'build_complete.json').exists() and exe.exists():return exe
 w=(E/'RegisteredContext.large.template.scala').read_text();scaled=mode.startswith('on_')
 w=w.replace('is(3.U){cmdFunct:=3.U;cmdRs1:=execution}', 'is(3.U){cmdFunct:=3.U;cmdRs1:=execution;cmdRs2:='+('cfgGroup' if scaled else '0.U')+'}')
 if scaled:w=w.replace('is(4.U){cmdFunct:=4.U}','is(4.U){cmdFunct:=4.U;cmdRs1:="ha00000".U}')
 ws=d/'RegisteredContext.scala';ws.write_text(w);classes=d/'wrapper_classes';classes.mkdir(exist_ok=True)
 el=load('elaborator',E/'scripts/elaborate_rtl.py');plugin='/home/kioannou/.cache/coursier/v1/https/repo1.maven.org/maven2/org/chipsalliance/chisel-plugin_2.13.16/6.7.0/chisel-plugin_2.13.16-6.7.0.jar'
 run([TOOLS/'bin/java','-cp',':'.join(el.compiler_jars(W)),'scala.tools.nsc.Main','-classpath',E/'toolchain/experimental.jar','-Xplugin:'+plugin,'-d',classes,ws],d/'wrapper_compile.log','COMPILE_CONTEXT',timeout=300)
 run([TOOLS/'bin/java','-cp',str(classes)+':'+str(E/'toolchain/experimental.jar'),'EmitContext',d/'wrapper_rtl'],d/'wrapper_emit.log','EMIT_CONTEXT',timeout=300)
 obj=d/'verilator';obj.mkdir(exist_ok=True);(obj/'sources.f').write_text('\n'.join([str(d/'wrapper_rtl/RegisteredContext.sv'),*m['sources']])+'\n')
 run([TOOLS/'bin/verilator','--cc','--exe','--build','-j','4','--top-module','RegisteredContext','--Mdir',obj,'--assert','--vpi','--public-flat-rw','-Wno-fatal','-CFLAGS','-O1 -std=c++17',*[f'-I{x}' for x in m['include_dirs']],'-f',obj/'sources.f',E/'driver.cpp'],d/'verilator_build.log','BUILD_VERILATOR',timeout=2400)
 save(d/'build_complete.json',dict(executable=str(exe),sha256=sha(exe)));return exe

def data(r,k,n,bits,g,pattern):
 seed=20261126+bits+k+n;v=REF.V.prepare(r,k,n,32,bits,seed=seed,fp_activations=True,group_scale_mode=2,group_size=g)
 q=[]
 if pattern=='random':
  rng=REF.V.newlib_rand(seed ^ 0xABCDEF)
  v.inputs=[((next(rng)&1)<<31)|((111+next(rng)%25)<<23)|(next(rng)&0x7fffff) for _ in range(r*k)]
 for c in range(n):
  col=[]
  for i in range(k):
   j=c*k+i;w=(v.packed_weights[j*bits//8]>>(j*bits%8))&((1<<bits)-1);col.append(w-(1<<bits) if w&(1<<(bits-1)) else w)
  q.append(col)
 if pattern in ['rne','underflow','overflow','cancellation']:
  palette={'rne':[0x3f800000,0x33800000,0x3f800001,0xb3800000], 'underflow':[1,0x80000001,0x00800000,0x80800000], 'overflow':[0x7f7fffff,0xff7fffff,0x7f000000,0xff000000], 'cancellation':[0x4b800001,0x3f800000,0xcb800001,0xbf800000]}[pattern]
  v.inputs=[palette[(y+i)%len(palette)] for y in range(r) for i in range(k)]
  q=[[((1<<(bits-1))-1) if pattern=='overflow' else (1 if i%3 else -1) for i in range(k)] for c in range(n)]
  v.scales=[([0x3c00,0xbc00,0x0001,0x3800,0][i%5] if pattern!='rne' else 0x3c00) for i in range(len(v.scales))]
 packed=bytearray((k*n*bits+7)//8)
 for c in range(n):
  for i in range(k):
   j=c*k+i;packed[j*bits//8]|=(q[c][i]&((1<<bits)-1))<<(j*bits%8)
 return v.inputs,q,bytes(packed),v.scales

def test(mode,exe,label,r,k,n,bits,g,pattern):
 d=E/'cases'/mode/'verification'/label;d.mkdir(parents=True,exist_ok=True)
 if (d/'verification.json').exists():
  old=json.loads((d/'verification.json').read_text());assert old['result']=='PASS';return old
 x,q,wb,scales=data(r,k,n,bits,g,pattern);xb=struct.pack('<'+'I'*len(x),*x);sb=struct.pack('<'+'H'*len(scales),*scales);mem=bytearray([0xa5])*MEMSIZE;mem[:len(xb)]=xb;mem[0x10000:0x10000+len(wb)]=wb;mem[0xa00000:0xa00000+len(sb)]=sb
 (d/'memory.bin').write_bytes(mem);save(d/'parameters.json',dict(R=r,K=k,N=n,bits=bits,G=g,pattern=pattern,seed=20261126+bits+k+n,synthetic=True))
 run([exe,k,n,bits,d/'memory.bin',d/'memory_output.bin',hex(0x12345+bits),g if mode.startswith('on_') else 0,r],d/'verilator.log','VERIFY_'+label,timeout=1800)
 expected=REF.reference(x,q,scales,r,k,n,bits,g,mode,d/'fragment_order.csv');expected_bytes=struct.pack('<'+'I'*len(expected),*expected);raw=(d/'memory_output.bin').read_bytes();got=raw[OUT:OUT+len(expected_bytes)];actual=list(struct.unpack('<'+'I'*len(expected),got));guards=raw[OUT-8:OUT]==mem[OUT-8:OUT] and raw[OUT+len(got):OUT+len(got)+8]==mem[OUT+len(got):OUT+len(got)+8]
 exact=REF.reference(x,q,scales,r,k,n,bits,g,'on_exact',d/'fragment_order.csv') if mode.startswith('on_') else REF.reference(x,q,scales,r,k,n,bits,g,'off_exact')
 text=(d/'verilator.log').read_text();cm=re.search(r'RESULT cycles=(\d+) counters=([0-9,]+)',text);assert cm;pc=list(map(int,cm[2].split(',')));stalls=re.search(r'OBSERVED fragment_fifo_backpressure=(\d+) selection_credit_stalls=(\d+)',text)
 record=dict(mode=mode,label=label,R=r,K=k,N=n,bits=bits,G=g,pattern=pattern,result='PASS' if got==expected_bytes and guards and (d/'write_payload.bin').read_bytes()==got else 'FAIL',elements=len(expected),bit_matches=sum(a==b for a,b in zip(actual,expected)),guards=guards,wrapper_cycles=int(cm[1]),load_x=pc[0],generate_brams=pc[1],load_w=pc[2],select_accumulate=pc[3],store_o=pc[4],load_w_and_select=pc[5],total=pc[0]+pc[1]+pc[4]+pc[5],fragment_fifo_backpressure=int(stalls[1]) if stalls else None,selection_credit_stalls=int(stalls[2]) if stalls else None,input_sha256=hashlib.sha256(xb).hexdigest(),weights_sha256=hashlib.sha256(wb).hexdigest(),scales_sha256=hashlib.sha256(sb).hexdigest(),output_sha256=hashlib.sha256(got).hexdigest(),accuracy=REF.metrics(actual,exact),synthetic=True,exact_reference_basis='same quantized weights and activations; no inference/quantization-quality claim')
 (d/'expected.bin').write_bytes(expected_bytes);(d/'output.bin').write_bytes(got);save(d/'verification.json',record)
 assert record['result']=='PASS',record
 # Keep input/actual payloads and hashes; 16MiB context dumps can remain for replay.
 return record

def verify(mode,m):
 exe=build(mode,m);records=[]
 for bits in [8,4,2]:
  for g in [32,64,128]:
   records.append(test(mode,exe,f'smoke_W{bits}_G{g}',4,g*2+4,3,bits,g,'random'))
 for pattern in ['rne','cancellation','underflow','overflow']:
  records.append(test(mode,exe,'edge_'+pattern,4,132,1,8,64,pattern))
 records.append(test(mode,exe,'inactive_R3',3,132,3,4,64,'random'))
 records.append(test(mode,exe,'deep_W2',4,2052,1,2,128,'random'))
 save(E/'cases'/mode/'smoke_summary.json',dict(result='PASS',tests=len(records),elements=sum(a['elements'] for a in records)))
 return exe

def larger(mode,exe):
 for bits in [8,4,2]:
  for name,k,n in [('Qwen_KV',1024,1024),('Qwen_GateUp',1024,3072)]:test(mode,exe,f'{name}_W{bits}',4,k,n,bits,128,'random')
 save(E/'cases'/mode/'larger_complete.json',dict(result='PASS',tests=6,synthetic=True,note='Representative full Qwen3-0.6B shapes, not end-to-end inference'))

def synthesis(mode,m):
 d=E/'cases'/mode/'synthesis';d.mkdir(exist_ok=True)
 if (d/'synthesis_complete.json').exists():return
 (d/'sources.txt').write_text('\n'.join(m['sources'])+'\n');(d/'include_dirs.txt').write_text('\n'.join(m['include_dirs'])+'\n')
 # Shared lock waits for the independent old sweep; never signal or alter it.
 with (OLD/'runner.lock').open('r') as dep:
  state('WAIT_EXISTING_SWEEP_BEFORE_SYNTHESIS',dependency=str(OLD/'runner.lock'));fcntl.flock(dep,fcntl.LOCK_SH)
  run(['/tools/Xilinx/Vivado/2023.2/bin/vivado','-mode','batch','-nojournal','-log',d/'vivado.log','-source',E/'flow/core_synthesis.tcl','-tclargs','LUMIXEDExample',d/'sources.txt',d/'include_dirs.txt','xcu250-figd2104-2-e','clock','20','synth',d],d/'console.log','VIVADO_SYNTHESIS_ONLY',timeout=5400)
 assert (d/'post_synth.dcp').exists();u=PARSE.parse_utilization(d/'utilization_post_synth.rpt');assert u['lut_total']>10000 and u['bram36']>0,'Accelerator pruning guard'
 save(d/'synthesis_complete.json',dict(result='PASS',resources=u,scope='accelerator-only synthesis; no placement/routing; power/timing preliminary'))

def report():
 rows=[]
 for mode in MODES:
  d=E/'cases'/mode;tests=[]
  for f in sorted((d/'verification').glob('*/verification.json')):tests.append(json.loads(f.read_text()))
  syn=json.loads((d/'synthesis/synthesis_complete.json').read_text()) if (d/'synthesis/synthesis_complete.json').exists() else {}
  main=[a for a in tests if a['label'].startswith('Qwen_')];summary=dict(mode=mode,tests=len(tests),passes=sum(a['result']=='PASS' for a in tests),cycles=sum(a['total'] for a in main) if main else None,**syn.get('resources',{}),relative_l2_max=max((a['accuracy']['relative_l2'] or 0 for a in main),default=None))
  if (d/'failure.json').exists():summary['failure']=json.loads((d/'failure.json').read_text())
  rows.append(summary)
  if tests:
   flat=[dict(**{k:v for k,v in a.items() if k!='accuracy'},**{'accuracy_'+k:v for k,v in a['accuracy'].items()}) for a in tests]
   keys=list(dict.fromkeys(k for a in flat for k in a))
   with (d/'cycles_accuracy.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(flat)
 save(E/'results.json',rows)
 lines=['# Rounded group-wise scaling investigation','', 'Actual completed evidence only. Missing metrics are unknown. All activation/weight data are synthetic. No inference-quality conclusion.','', '| Design | Tests PASS | Larger aggregate cycles | LUT | FF | DSP | BRAM36/18 | URAM | Frequency | Relative L2 max |','|---|---|---:|---:|---:|---:|---|---:|---|---:|']
 for a in rows:lines.append('| '+' | '.join(map(str,[a['mode'],f"{a['passes']}/{a['tests']}",a['cycles'],a.get('lut_total','—'),a.get('ff','—'),a.get('dsp','—'),str(a.get('bram36','—'))+'/'+str(a.get('bram18','—')),a.get('uram','—'),'Synthesis estimate pending',a['relative_l2_max']]))+' |')
 lines+=['','RTL baseline: '+(E/'base_revision.txt').read_text().strip(),'', 'Modes A/B use ROUNDED_ACCUMULATION=true plus GROUP_SCALE_ROUNDING=1/2. Mode A rounds exact scaled bank fragments; B rounds each fragment then uses single-round FP32 FMA. Existing exact and rounded OFF paths are preserved. All modes match B8/RF4/YS4/ID8, R4/K3072/N3072, beat8, two weight buffers, GROUP_SCALE_YS4. Output SRAM and feedback forwarding use one synchronous read plus combinational FP32 add/FMA; measured cycles/stalls must establish actual throughput.','', 'Rounded reference validates observed FIFO metadata against an independently enumerated per-bank fragment stream and recalculates every subtotal from inputs. It never uses DUT arithmetic to construct expected values. Observed order is used because RR arbitration under stalls is data-independent scheduling that affects FP32 association. Signed-zero/NaN canonicalization, ties and true fused rounding are explicit.','', 'Cycles aggregate six full synthetic Qwen-shaped GEMMs (KV and Gate/Up x W8/W4/W2), not 196-projection or full-inference latency. Power/frequency from synthesis are preliminary and do not establish timing closure. No placement/routing.','', 'Reproduce/resume: python3 investigate.py start; status: python3 investigate.py status. Completed phases are reused; failed phases preserve logs and can be retried after correcting a blocker. All writable files/caches/temp are under /var/tmp/lumixed-rounded-scaling.3q0lokdm/. Original checkout/artifacts untouched. No commit/push/merge.']
 (E/'RESULTS.md').write_text('\n'.join(lines)+'\n')

def main():
 global MODE
 lock=(E/'runner.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 eligible=os.sched_getaffinity(0);cpus={12,13,14,15}&eligible;assert len(cpus)==4
 if Path('/proc/2944045/cmdline').exists():
  cmd=Path('/proc/2944045/cmdline').read_bytes()
  if bytes(str(OLD/'run_sweep.py'),'utf8') in cmd:assert not (cpus&os.sched_getaffinity(2944045)),'CPU overlap with independent sweep'
 os.sched_setaffinity(0,cpus);os.nice(12);state('STARTED',source_branch='experiment/rounded-group-scaling')
 manifests={};executables={}
 for mode in MODES:
  MODE=mode
  try:manifests[mode]=emit(mode);executables[mode]=verify(mode,manifests[mode])
  except Exception as ex:save(E/'cases'/mode/'failure.json',dict(error=str(ex),traceback=traceback.format_exc()));state('CASE_FAILED',error=str(ex));traceback.print_exc()
  report()
 if len(executables)!=5:state('FUNCTIONAL_GATE_FAILED',passed=list(executables));return
 for mode in MODES:
  MODE=mode
  try:larger(mode,executables[mode])
  except Exception as ex:save(E/'cases'/mode/'failure.json',dict(error=str(ex),traceback=traceback.format_exc()));state('LARGER_FAILED',error=str(ex));traceback.print_exc()
  report()
 if not all((E/'cases'/mode/'larger_complete.json').exists() for mode in MODES):state('LARGER_GATE_FAILED');return
 for mode in MODES:
  MODE=mode
  try:synthesis(mode,manifests[mode])
  except Exception as ex:save(E/'cases'/mode/'failure.json',dict(error=str(ex),traceback=traceback.format_exc()));state('SYNTHESIS_FAILED',error=str(ex));traceback.print_exc()
  report()
 MODE=None;state('COMPLETE');report()
if __name__=='__main__':
 action=sys.argv[1] if len(sys.argv)>1 else 'status'
 if action=='worker':main()
 elif action=='start':
  f=(E/'runner.lock').open('a')
  try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise SystemExit('Already running')
  f.close()
  with (E/'runner.log').open('ab',buffering=0) as log:p=subprocess.Popen([sys.executable,'-u',str(Path(__file__)),'worker'],cwd=E,env=ENV,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (E/'worker.pid').write_text(str(p.pid));print('Detached experiment runner PID',p.pid)
 elif action=='status':print((E/'status.json').read_text() if (E/'status.json').exists() else 'Not started')
 else:raise SystemExit('Usage: investigate.py start|status|worker')
