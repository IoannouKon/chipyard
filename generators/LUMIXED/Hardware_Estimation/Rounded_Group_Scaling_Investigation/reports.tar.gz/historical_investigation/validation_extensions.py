from pathlib import Path
import os,sys,time,json,csv,importlib.util,traceback
sys.dont_write_bytecode=True
E=Path(__file__).resolve().parent
os.sched_setaffinity(0,{12,13,14,15});os.nice(14)
spec=importlib.util.spec_from_file_location('investigation',E/'investigate.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
deadline=time.monotonic()+3*3600
while not all((E/'cases'/mode/'smoke_summary.json').exists() for mode in m.MODES):
 if time.monotonic()>deadline:raise RuntimeError('Timeout waiting for five smoke gates')
 time.sleep(15)
original=m.data
# Group engine schedules metadata independently of numeric values. Use its
# archived first two FIFO grants to construct a reproducible fused-cancellation
# vector, then recompute the full reference from independently calculated sums.
events=list(csv.DictReader((E/'cases/on_b/verification/edge_rne/fragment_order.csv').open()));banks=[int(e['bank']) for e in events if e['initialize']=='0'][:2]
assert len(set(banks))==2

def extended(r,k,n,bits,g,pattern):
 x,q,wb,sc=original(r,k,n,bits,g,'random')
 x=[0]*(r*k);q=[[1]*k for _ in range(n)];sc=[0x3c00]*len(sc)
 if pattern=='literal_rne_tie':
  for y in range(r):x[y*k]=0x3f800000+(y&1);x[y*k+1]=0x33800000;x[y*k+4]=0x33800000
 elif pattern=='literal_fused_cancellation':
  for y in range(r):x[y*k+banks[0]*4]=0xbf800000;x[y*k+banks[1]*4]=0x3f800001
  for col in range(n):sc[col]=0x3bff
 else:raise ValueError(pattern)
 packed=bytearray((k*n*bits+7)//8)
 for j in range(k*n):packed[j*bits//8]|=1<<(j*bits%8)
 return x,q,bytes(packed),sc
m.data=extended;records=[]
try:
 for mode in m.MODES:
  m.MODE=mode;exe=E/'cases'/mode/'verilator/VRegisteredContext'
  for pattern in ['literal_rne_tie','literal_fused_cancellation']:
   records.append(m.test(mode,exe,pattern,4,132,1,8,64,pattern))
 (E/'extended_numeric_gate.json').write_text(json.dumps(dict(result='PASS',tests=len(records),elements=sum(r['elements'] for r in records),fused_stimulus_first_banks=banks),indent=2)+'\n')
except Exception as ex:
 (E/'extended_numeric_gate.json').write_text(json.dumps(dict(result='FAIL',error=str(ex),traceback=traceback.format_exc()),indent=2)+'\n');raise
