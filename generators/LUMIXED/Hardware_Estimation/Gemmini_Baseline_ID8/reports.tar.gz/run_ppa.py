#!/usr/bin/env python3
"""Background FP32/W8 baseline-compatible Gemmini4/8 ID8 PPA, no cycle tests."""
from pathlib import Path
import argparse,csv,datetime,fcntl,hashlib,json,os,shutil,signal,subprocess,sys,traceback,zipfile
ROOT=Path(__file__).resolve().parent;REPO=Path('/home/kioannou/chipyard_1.15.0');PKG=Path('/home/kioannou/lumixed_v1_ppa_package');T=Path('/home/kioannou/chipyard_1.13.0/.conda-env');PREVIOUS=Path('/home/kioannou/artifacts/lumixed_gemmini_implementation_8cores_20261124');VIVADO='/tools/Xilinx/Vivado/2023.2/bin/vivado';PART='xcu250-figd2104-2-e';THREADS=8;MHZ=50
IDS=[f'gemmini_baseline_{n}x{n}_fp32_w8_id8' for n in (4,8)]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def state(phase,**kw):
 x=dict(phase=phase,pid=os.getpid(),updated=datetime.datetime.now().astimezone().isoformat(),threads=THREADS,part=PART,target_mhz=MHZ,designs=IDS,**kw);write(ROOT/'status.json',x);print(x,flush=True)
def run(cmd,label):
 write(ROOT/(label+'.command.json'),list(map(str,cmd)))
 with (ROOT/(label+'.log')).open('a') as f:p=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT,env=ENV)
 if p.returncode:raise RuntimeError(f'{label} exit{p.returncode}: see {ROOT/(label+".log")}')
def summary():
 sys.path.insert(0,str(ROOT/'flow'));from run_vivado import parse_utilization,tsv,parse_timing_checks
 rows=[]
 for id in IDS:
  p=ROOT/'results'/PART/id;m=json.loads((p/'metrics.json').read_text()) if (p/'metrics.json').exists() else {};live=tsv(p/'status.tsv') if (p/'status.tsv').exists() else {};routed=m.get('resource_stage')=='post_route';internal=tsv(p/'internal_timing.tsv') if (p/'internal_timing.tsv').exists() else {};power=m.get('power_post_route_vectorless',{}) if routed else {}
  stage=live.get('stage',m.get('resource_stage',''));u=parse_utilization(p/{'post_synthesis':'utilization_post_synth.rpt','placed':'utilization_post_place.rpt','post_route':'utilization_post_route.rpt'}.get(stage,'missing'))
  row=dict(design=id,status=live.get('status',m.get('status','QUEUED')),stage=stage,part=PART,target_mhz=MHZ,threads=THREADS,setup_slack_ns=m.get('worst_setup_slack_ns','') if routed else '',hold_slack_ns=m.get('worst_hold_slack_ns','') if routed else '',internal_setup_slack_ns=internal.get('internal_setup_slack_ns',''),internal_hold_slack_ns=internal.get('internal_hold_slack_ns',''),estimated_internal_setup_fmax_mhz=m.get('estimated_fmax_mhz','') if routed else '',dynamic_power_w=power.get('dynamic_w',''),static_power_w=power.get('static_w',''),total_power_w=power.get('total_w',''),power_confidence=power.get('confidence',''))
  for k in ['lut_total','ff','dsp','bram36','bram18','uram']:row[k]=u.get(k,'')
  rows.append(row)
 with (ROOT/'results.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 return rows

def worker():
 global ENV
 os.chdir(ROOT);lock=(ROOT/'worker.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 cores=sorted(os.sched_getaffinity(0))[:THREADS];os.sched_setaffinity(0,cores);os.nice(10);ENV=os.environ.copy();ENV.update(OMP_NUM_THREADS=str(THREADS),PPA_MAX_THREADS=str(THREADS),JAVA_TOOL_OPTIONS='-Xmx3G -Xss8M -XX:ActiveProcessorCount=8')
 try:
  state('COMPILE',cpu_affinity=cores);sys.path.insert(0,str(PKG/'scripts'));from elaborate_rtl import compiler_jars
  flow=ROOT/'flow';flow.mkdir(exist_ok=True)
  for name in ['run_vivado.py','vivado_ppa_ooc.tcl','ooc_clock_integration.tcl']:shutil.copy2(PREVIOUS/'flow'/name,flow/name)
  base=PKG/'work/toolchain/chipyard.jar';classes=ROOT/'classes';classes.mkdir(exist_ok=True);jar=ROOT/'generator.jar';plugin=Path('/home/kioannou/.cache/coursier/v1/https/repo1.maven.org/maven2/org/chipsalliance/chisel-plugin_2.13.16/6.7.0/chisel-plugin_2.13.16-6.7.0.jar')
  sources=[REPO/'generators/gemmini/src/main/scala/gemmini/ConfigsFP.scala',REPO/'generators/chipyard/src/main/scala/config/GemminiEditedConfigs.scala',ROOT/'CheckConfigs.scala'];write(ROOT/'source_sha256.json',{str(p):sha(p) for p in sources})
  run([T/'bin/java','-cp',':'.join(compiler_jars(REPO)),'scala.tools.nsc.Main','-classpath',base,f'-Xplugin:{plugin}','-d',classes,*sources],'compile')
  with zipfile.ZipFile(base) as old,zipfile.ZipFile(jar,'w') as new:
   changes={str(p.relative_to(classes)):p for p in classes.rglob('*.class')}
   for info in old.infolist():
    if info.filename not in changes:
     content=old.read(info.filename);info.compress_type=zipfile.ZIP_STORED;new.writestr(info,content)
   for name,p in changes.items():new.write(p,name)
  run([T/'bin/java','-cp',jar,'gemmini.baselineppacheck.CheckConfigs'],'parameter_assertions')
  fpga=ROOT/'fpga_classes';fpga.mkdir(exist_ok=True)
  run([T/'bin/java','-cp',':'.join(compiler_jars(REPO)),'scala.tools.nsc.Main','-classpath',str(jar)+':/tmp/lumixed-1.15-validation/classpath/chipyard_fpga.jar','-d',fpga,REPO/'fpga/src/main/scala/zcu106/Configs.scala'],'fpga_selector_compile')
  designs=[]
  for n,id in zip((4,8),IDS):
   d=dict(id=id,accelerator='GemminiEdited',array=f'{n}x{n}',mode='unscaled',activation='FP32',weight_modes=[8],output='FP32',scratchpad_KiB=32,accumulator_KiB=4,dma_bits=64,dma_max_bytes=64,in_flight_requests_per_pool=8,acc_read_small_width=False,has_dw_convs=False);designs.append(d)
   overlay=ROOT/'overlays'/id;overlay.mkdir(parents=True,exist_ok=True);cls=f'PPABaselineFP32Gemmini{n}';(overlay/(cls+'.scala')).write_text(f'package ppa\nimport org.chipsalliance.cde.config.Config\nclass {cls} extends Config(new chipyard.EditedGemmini{n}BaselineRocketConfig)\n');write(overlay/'overlay.json',dict(config_class=cls,package='ppa'))
  write(ROOT/'plan.json',dict(designs=designs));state('ELABORATE',cpu_affinity=cores)
  run([sys.executable,PKG/'scripts/elaborate_rtl.py','--repo',REPO,'--plan',ROOT/'plan.json','--overlays',ROOT/'overlays','--out',ROOT/'elaboration','--rtl-dir',ROOT/'rtl','--jar',jar,'--tapeout',PKG/'work/toolchain/tapeout.jar','--tools-prefix',T],'elaborate')
  run([sys.executable,PKG/'scripts/review_rtl.py','--plan',ROOT/'plan.json','--rtl-dir',ROOT/'rtl'],'boundary_review')
  def walk(node):
   yield node
   for c in node.get('instances',[]):yield from walk(c)
  for n,id in zip((4,8),IDS):
   m=json.loads((ROOT/'rtl'/(id+'.json')).read_text());tree=json.loads((Path(m['origin_filelist']).parent/'top_module_hierarchy.json').read_text());top=next(x for x in walk(tree) if x['module_name']=='Gemmini');nodes=list(walk(top));assert sum(x['module_name']=='FPIntMac' for x in nodes)==n*n
   assert not any(x['module_name'].startswith(('ScalePipe','AccScalePipe')) for x in nodes)
  for n,id in zip((4,8),IDS):
   for stage in ['synth','route']:
    state('SYNTHESIS' if stage=='synth' else 'IMPLEMENTATION',active_design=id,cpu_affinity=cores)
    run([sys.executable,'-u',flow/'run_vivado.py','--plan',ROOT/'plan.json','--rtl-dir',ROOT/'rtl','--out',ROOT/'results','--vivado',VIVADO,'--part',PART,'--clock-mhz',str(MHZ),'--stage',stage,'--max-threads',str(THREADS),'--select',id],f'{id}_{stage}')
    m=json.loads((ROOT/'results'/PART/id/'metrics.json').read_text());summary()
    if stage=='synth' and m['status']!='SYNTH_PASS':break
   state('DESIGN_ATTEMPT_COMPLETE',last_design=id,status=m['status'],cpu_affinity=cores)
  rows=summary();state('COMPLETE',results=rows,cpu_affinity=cores)
 except Exception as e:
  state('FAILED',error=str(e));traceback.print_exc()
  try:summary()
  except Exception:pass
  raise

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('action',choices=['start','status','stop','worker']);x=a.parse_args()
 if x.action=='worker':worker();return
 lock=(ROOT/'start.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
 pidfile=ROOT/'worker.pid';pid=int(pidfile.read_text()) if pidfile.exists() else None
 def active():
  if not pid:return False
  p=Path(f'/proc/{pid}/cmdline');return p.exists() and str(Path(__file__).resolve()).encode() in p.read_bytes()
 if x.action=='start':
  if active():print('Already running PID',pid);return
  with (ROOT/'runner.log').open('a') as f:p=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'worker'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  pidfile.write_text(str(p.pid)+'\n');print('Started detached PPA worker PID',p.pid);return
 if x.action=='status':
  print('Active:',active(),'PID:',pid)
  if (ROOT/'status.json').exists():print((ROOT/'status.json').read_text())
  if (ROOT/'results.csv').exists():print((ROOT/'results.csv').read_text())
  return
 if active():
  assert os.getpgid(pid)==pid;os.killpg(pid,signal.SIGTERM);write(ROOT/'status.json',dict(phase='STOPPED_BY_USER'));print('Stopped PID group',pid)
 else:print('Not running')
if __name__=='__main__':main()
