package ppa
import org.chipsalliance.cde.config.Config
class PPABaselineFP32Gemmini4 extends Config(new chipyard.EditedGemmini4BaselineRocketConfig)
