package ppa
import org.chipsalliance.cde.config.Config
class PPABaselineFP32Gemmini8 extends Config(new chipyard.EditedGemmini8BaselineRocketConfig)
