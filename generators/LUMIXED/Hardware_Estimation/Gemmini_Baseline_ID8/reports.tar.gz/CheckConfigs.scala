package gemmini.baselineppacheck
import gemmini._
object CheckConfigs {
 def main(args:Array[String]):Unit={
  for ((n,c) <- Seq((4,GemminiFPConfigs.editedBaseline4FP32Config),(8,GemminiFPConfigs.editedBaseline8FP32Config))) {
   require(c.meshRows==n && c.meshColumns==n && c.tileRows==1 && c.tileColumns==1)
   require(c.GEMMINI_EDITED && c.weightBits==8 && c.dataflow==Dataflow.WS)
   require(c.inputType.getWidth==32 && c.accType.getWidth==32 && c.spatialArrayOutputType.getWidth==32)
   require(c.max_in_flight_mem_reqs==8 && !c.acc_read_small_width && !c.has_dw_convs)
   require(c.sp_capacity==CapacityInKilobytes(32) && c.acc_capacity==CapacityInKilobytes(4))
   require(c.dma_buswidth==64 && c.dma_maxbytes==64 && c.sp_banks==4 && c.acc_banks==1)
   require(c.mvin_scale_args.isEmpty && c.mvin_scale_acc_args.isEmpty && c.acc_scale_args.isEmpty)
   require(c.hardcode_d_to_garbage_addr && !c.has_nonlinear_activations && !c.has_max_pool && !c.has_normalizations)
   require(!c.clock_gate && c.tile_latency==2)
   println(s"PASS ${n}x$n: FP32/W8 WS-only, no scale/bias/nonlinear; SP32/ACC4; ID8; small-width read OFF; depthwise OFF")
  }
  require(GemminiFPConfigs.editedConfig(true,4).max_in_flight_mem_reqs==16)
  require(GemminiFPConfigs.editedConfig(true,8).max_in_flight_mem_reqs==16)
  require(GemminiFPConfigs.editedConfig(false,4) eq GemminiFPConfigs.FP32DefaultConfig)
  println("PASS: original ID16 and stock selectors unchanged")
 }
}
