# Baseline-compatible FP32 Gemmini PPA

Fresh synthesis, placement, clock integration, routing, timing and vectorless
power analysis for 4x4 and 8x8 edited Gemmini. No cycle benchmark is rerun.

Both configurations use FP32 activations, signed INT8 weights, FP32 outputs,
weight-stationary-only execution, no arithmetic scaling, SP32 KiB/ACC4 KiB,
8 outstanding DMA requests per pool, 64-bit DMA, 64-byte maximum DMA requests,
`acc_read_small_width=false` and `has_dw_convs=false`.

Vivado 2023.2, U250 `xcu250-figd2104-2-e`, 50 MHz target, up to eight CPU cores,
sequential designs. Existing supplied evaluation scripts are reused in `flow/`.
The normal Chipyard selectors are `EditedGemmini4BaselineRocketConfig` and
`EditedGemmini8BaselineRocketConfig`. Original ID16 comparison configurations
are preserved. Private compiled generator classes, source hashes and exact
commands are retained here.

```sh
python3 /home/kioannou/artifacts/gemmini_baseline_id8_ppa_20261125/run_ppa.py status
```

Results are written to `results.csv`; complete reports, logs and checkpoints
are under `results/xcu250-figd2104-2-e/`. A completed run does not imply a timing
pass: inspect both setup and hold, including boundary paths. Estimated internal
setup Fmax is diagnostic, not proof of an achievable operating frequency.
Power is vectorless, not workload-measured. Historical full-SoC ZCU106 FP16
results and current accelerator-only U250 FP32 results are separate environments.
