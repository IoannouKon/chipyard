from pathlib import Path
import json,csv,hashlib
from collections import Counter
r=Path(__file__).resolve().parent;d=json.loads((r/'comparison.json').read_text());job=r/'results'/d['part']/'lumixed_scaled_B8_RF4_YS4_ID8_R4_GSYS2'
def hierarchy(p):
 a=p.read_text().splitlines()[1:];return len(a),sum('groupEngine/' in x for x in a),Counter('/'.join(x.split('\t')[0].split('/')[:2]) for x in a)
btotal,bscale,bpaths=hierarchy(r/'baseline/dsp_hierarchy.tsv');total,scale,paths=hierarchy(job/'dsp_hierarchy.tsv');assert btotal==70 and total==d['new']['dsp'];assert d['scale_dsp_cells']==scale
rows=[]
for k in ['dsp','lut_total','ff','bram36','bram18','uram']:
 b=d['baseline'][k];n=d['new'][k];rows.append(dict(resource=k,baseline_group_scale_ys4=b,new_group_scale_ys2=n,change=n-b))
rows.insert(1,dict(resource='scaling_engine_dsp',baseline_group_scale_ys4=bscale,new_group_scale_ys2=scale,change=scale-bscale))
with (r/'resources.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['| Resource | Archived GSYS4 | New GSYS2 | Change |','|---|---:|---:|---:|']+[f"| {x['resource']} | {x['baseline_group_scale_ys4']:,} | {x['new_group_scale_ys2']:,} | {x['change']:+,} |" for x in rows]
(r/'README.md').write_text('''# GROUP_SCALE_YS=2: Vivado synthesis-only measurement

Source revision: `405d4229c53ce83e8c01042876746e0b762002d5`.
Configuration: B8/RF4/YS4/ID8, Rin4/Cin3072/Cout3072, FP32 activations/output,
signed runtime W8/W4/W2, deferred FP16 group scales ON, aligned scaling OFF,
BRAM outputs ON, two weight buffers, DMA beat 8 bytes, performance counters ON,
all other optional experiments OFF. Only the private overlay sets
`GROUP_SCALE_YS=2`; production RTL was not edited.

Vivado 2023.2, `xcu250-figd2104-2-e`, accelerator-only OOC synthesis,
`-flatten_hierarchy none`, two CPU cores. The synthesis Tcl is byte-identical
to the archived baseline. Same post-synthesis constraints: ppa_clk 20 ns/50 MHz,
zero external I/O delays, reset false path. The supplied flow creates these
constraints after synth_design, identically to the archived experiment.

Synthesis PASS, zero unresolved black boxes. Generated engine RTL and the
instantiated accelerator hierarchy both contain exactly TWO ExactScaleMultiplier
instances (shifted_multiplier and shifted_multiplier_1).

'''+ '\n'.join(lines)+f'''

Total DSP reduction: {100*(btotal-total)/btotal:.3f}%.
Baseline hierarchy: {dict(bpaths)}.
New hierarchy: {dict(paths)}.

The scaling-engine total includes the group-index calculation, not just the
exact scaling multipliers. DSP48E2 cells were counted by exact REF_NAME and
cross-checked against utilization reports; broad DSP* patterns can overcount
subcomponents. Baseline checkpoint SHA256 matches the committed archive:
5a921bcb1b2c492150c09bfde9e3d38d3ba3c05d33e74dd0dbf187c706aa53df.
The reused baseline has GROUP_SCALE_YS=4-equivalent full-row parallel scaling.
Its source revision is 62b02896b6c5cf5b8fbd36e62fc776f331a77c74;
its synthesis was not rerun. Original archived reports remain unchanged.

No placement, routing, bitstream, cycle benchmark or functional simulation was
run. This experiment establishes resource counts, not timing, power or numerical
correctness for the new serialization mode. Preliminary synthesis timing/power
files produced by the supplied flow are not implementation measurements.

Evidence: source_snapshot/, source_sha256.json, overlays/, plan.json,
rtl_instance_check.json, GroupScaleEngine.generated.sv, baseline/,
results/{d['part']}/lumixed_scaled_B8_RF4_YS4_ID8_R4_GSYS2/,
including utilization_post_synth.rpt, utilization_hierarchical.rpt,
dsp_hierarchy.tsv, original Vivado log and post_synth.dcp. Exact commands are
recorded in *.command.json. The first interrupted attempt is retained separately
in interrupted_attempt/ and interrupted_*. Its incomplete log is not a result.

Reproduce the full synthesis-only experiment at the recorded repository revision:

```sh
cd /home/kioannou/artifacts/lumixed_group_scale_ys2_synth_20261125
python3 run.py
/tools/Xilinx/Vivado/2023.2/bin/vivado -mode batch -source baseline_hierarchy.tcl
python3 summarize.py
```

The local package/toolchain paths are recorded in run.py. finish.py resumes
from verified generated RTL and was used for the detached retry; it performs
synthesis and report-only checkpoint inspection, never place_design/route_design.
''')
print('\n'.join(lines));print('DSP reduction %',100*(btotal-total)/btotal)
