set_param general.maxThreads 2
open_checkpoint {/home/kioannou/artifacts/lumixed_scaled_id8_synthesis_20261124/results/xcu250-figd2104-2-e/lumixed_scaled_B8_RF4_YS4_ID8_R4/post_synth.dcp}
report_utilization -hierarchical -hierarchical_depth 12 -file {/home/kioannou/artifacts/lumixed_group_scale_ys2_synth_20261125/baseline/utilization_hierarchical.rpt}
set f [open {/home/kioannou/artifacts/lumixed_group_scale_ys2_synth_20261125/baseline/dsp_hierarchy.tsv} w]
puts $f "cell\tref_name"
foreach c [get_cells -hierarchical -filter {REF_NAME == DSP48E2}] {puts $f "$c\t[get_property REF_NAME $c]"}
close $f
exit
