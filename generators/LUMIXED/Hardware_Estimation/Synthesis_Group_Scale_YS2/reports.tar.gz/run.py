#!/usr/bin/env python3
"""Synthesis only: archived B8/RF4/YS4/ID8 parameters, GROUP_SCALE_YS=2."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,traceback,zipfile,re,csv
ROOT=Path(__file__).resolve().parent;REPO=Path('/home/kioannou/chipyard_1.15.0');PKG=Path('/home/kioannou/lumixed_v1_ppa_package');OLD=Path('/home/kioannou/artifacts/lumixed_scaled_id8_synthesis_20261124');TOOLS=Path('/home/kioannou/chipyard_1.13.0/.conda-env');ID='lumixed_scaled_B8_RF4_YS4_ID8_R4_GSYS2';BASE='lumixed_scaled_B8_RF4_YS4_ID8_R4';PART='xcu250-figd2104-2-e';VIVADO='/tools/Xilinx/Vivado/2023.2/bin/vivado';REV='405d4229c53ce83e8c01042876746e0b762002d5'
os.chdir(ROOT);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
ENV=os.environ.copy();ENV.update(JAVA_TOOL_OPTIONS='-Xmx3G -Xss8M -XX:ActiveProcessorCount=2',OMP_NUM_THREADS='2',PPA_MAX_THREADS='2')
sys.path.insert(0,str(PKG/'scripts'));from elaborate_rtl import compiler_jars;from run_vivado import parse_utilization

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def state(phase,**kw):
 d=dict(phase=phase,pid=os.getpid(),updated=datetime.datetime.now().astimezone().isoformat(),source_revision=REV,design=ID,**kw);write(ROOT/'status.json',d);print(d,flush=True)
def run(cmd,label):
 write(ROOT/(label+'.command.json'),list(map(str,cmd)))
 with (ROOT/(label+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT,env=ENV)
 if r.returncode:raise RuntimeError(f'{label} exit {r.returncode}')
try:
 state('PREPARE');assert subprocess.check_output(['git','-C',REPO,'rev-parse','HEAD'],text=True).strip()==REV
 sources=sorted((REPO/'generators/LUMIXED/src/main/scala').glob('*.scala'));snapshot=ROOT/'source_snapshot';snapshot.mkdir(exist_ok=True)
 for p in sources:
  relative=str(p.relative_to(REPO));expected=subprocess.check_output(['git','-C',REPO,'show',REV+':'+relative]);assert p.read_bytes()==expected,relative;shutil.copy2(p,snapshot/p.name)
 write(ROOT/'source_sha256.json',{str(p.relative_to(REPO)):sha(p) for p in sources})
 plan=json.loads((OLD/'plan.json').read_text());d=next(x for x in plan['designs'] if x['id']==BASE);d=dict(d,id=ID,GROUP_SCALE_YS=2);plan['designs']=[d];plan['source_revision']=REV;write(ROOT/'plan.json',plan)
 overlay=ROOT/'overlays'/ID;overlay.mkdir(parents=True,exist_ok=True);oldoverlay=OLD/'overlays'/BASE
 for p in oldoverlay.iterdir():
  s=p.read_text()
  if p.suffix=='.scala':s=s.replace('GROUP_SCALE_DEFERRED=true,','GROUP_SCALE_DEFERRED=true, GROUP_SCALE_YS=2,')
  (overlay/p.name).write_text(s)
 baseline=ROOT/'baseline';baseline.mkdir(exist_ok=True)
 for n in ['utilization_post_synth.rpt','metrics.json','input_metadata.json']:shutil.copy2(OLD/'results'/PART/BASE/n,baseline/n)
 before=parse_utilization(baseline/'utilization_post_synth.rpt');assert before['dsp']==70
 state('COMPILE_SOURCE');classes=ROOT/'classes';classes.mkdir(exist_ok=True);base=PKG/'work/toolchain/chipyard.jar';jar=ROOT/'chipyard_updated.jar';plugin=Path('/home/kioannou/.cache/coursier/v1/https/repo1.maven.org/maven2/org/chipsalliance/chisel-plugin_2.13.16/6.7.0/chisel-plugin_2.13.16-6.7.0.jar')
 run([TOOLS/'bin/java','-cp',':'.join(compiler_jars(REPO)),'scala.tools.nsc.Main','-classpath',base,f'-Xplugin:{plugin}','-d',classes,*sources],'compile')
 with zipfile.ZipFile(base) as old,zipfile.ZipFile(jar,'w') as new:
  for info in old.infolist():
   if info.filename.startswith('LUMIXED_PACKAGE/') and info.filename.endswith('.class'):continue
   data=old.read(info.filename);info.compress_type=zipfile.ZIP_STORED;new.writestr(info,data)
  for p in classes.rglob('*.class'):new.write(p,str(p.relative_to(classes)))
 state('ELABORATE',jar_sha256=sha(jar))
 run([sys.executable,PKG/'scripts/elaborate_rtl.py','--repo',REPO,'--plan',ROOT/'plan.json','--overlays',ROOT/'overlays','--out',ROOT/'elaboration','--rtl-dir',ROOT/'rtl','--jar',jar,'--tapeout',PKG/'work/toolchain/tapeout.jar','--tools-prefix',TOOLS],'elaborate')
 run([sys.executable,PKG/'scripts/review_rtl.py','--plan',ROOT/'plan.json','--rtl-dir',ROOT/'rtl'],'review')
 meta=json.loads((ROOT/'rtl'/(ID+'.json')).read_text());engine=next(Path(p) for p in meta['sources'] if Path(p).name=='GroupScaleEngine.sv');s=engine.read_text();instances=re.findall(r'ExactScaleMultiplier\s*#\([\s\S]*?\)\s+(\w+)\s*\(',s);assert len(instances)==2,instances
 write(ROOT/'rtl_instance_check.json',dict(engine=str(engine),exact_scale_multiplier_instances=instances,count=len(instances)));shutil.copy2(engine,ROOT/'GroupScaleEngine.generated.sv')
 # Hierarchy independently confirms instantiated module count, not just declarations.
 def walk(n):
  yield n
  for c in n.get('instances',[]):yield from walk(c)
 tree=json.loads((Path(meta['origin_filelist']).parent/'top_module_hierarchy.json').read_text());nodes=list(walk(tree));top=next(n for n in nodes if n['module_name']==meta['top']);assert sum(n['module_name']=='ExactScaleMultiplier' for n in walk(top))==2
 state('RTL_VERIFIED',exact_scale_multiplier_instances=2)
 # The original flow and settings are reused byte-for-byte; hierarchy reporting is a separate checkpoint read.
 flow=ROOT/'flow';flow.mkdir(exist_ok=True)
 for n in ['run_vivado.py','vivado_ppa_ooc.tcl','ooc_clock_integration.tcl']:shutil.copy2(PKG/'scripts'/n,flow/n)
 state('SYNTHESIS',exact_scale_multiplier_instances=2)
 run([sys.executable,'-u',flow/'run_vivado.py','--plan',ROOT/'plan.json','--rtl-dir',ROOT/'rtl','--out',ROOT/'results','--vivado',VIVADO,'--part',PART,'--clock-mhz','50','--stage','synth','--max-threads','2','--select',ID],'synthesis')
 job=ROOT/'results'/PART/ID;m=json.loads((job/'metrics.json').read_text());assert m['status']=='SYNTH_PASS' and m['exit_code']==0 and m['vivado_state']['blackbox_count']=='0',m
 state('HIERARCHY_REPORTS')
 tcl=ROOT/'hierarchy.tcl';tcl.write_text('set_param general.maxThreads 2\nopen_checkpoint {'+str(job/'post_synth.dcp')+'}\nreport_utilization -hierarchical -hierarchical_depth 12 -file {'+str(job/'utilization_hierarchical.rpt')+'}\nset f [open {'+str(job/'dsp_hierarchy.tsv')+'} w]\nputs $f "cell\\tref_name"\nforeach c [get_cells -hierarchical -filter {REF_NAME == DSP48E2}] {puts $f "$c\\t[get_property REF_NAME $c]"}\nclose $f\nexit\n')
 run([VIVADO,'-mode','batch','-source',tcl,'-log',ROOT/'hierarchy_vivado.log','-journal',ROOT/'hierarchy_vivado.jou'],'hierarchy')
 after=parse_utilization(job/'utilization_post_synth.rpt');dsp_lines=(job/'dsp_hierarchy.tsv').read_text().splitlines()[1:];scale=[l for l in dsp_lines if 'groupEngine/' in l]
 write(ROOT/'comparison.json',dict(source_revision=REV,configuration=d,part=PART,baseline=before,new=after,dsp_cells=len(dsp_lines),scale_dsp_cells=len(scale),scale_dsp_paths=scale,synthesis_status=m['status']))
 state('COMPLETE',resources=after,total_dsp=after['dsp'],scaling_engine_dsp=len(scale))
except Exception as e:state('FAILED',error=str(e));traceback.print_exc();raise
