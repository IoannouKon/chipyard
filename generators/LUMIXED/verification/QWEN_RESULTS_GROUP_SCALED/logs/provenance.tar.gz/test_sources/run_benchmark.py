#!/usr/bin/env python3
"""Current-RTL exact FP32 GEMMs, paired scaling OFF/ON; never edits RTL or old results."""
import argparse,csv,datetime,fcntl,hashlib,importlib.util,json,os,re,shutil,struct,subprocess,sys,time,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
CY=HERE.parents[3]
ARCHIVE=CY/'generators/LUMIXED/verification/QWEN_RESULTS'
OUTPUT=CY/'generators/LUMIXED/verification/QWEN_UNSCALED_RESULTS'
CACHE=HERE/'cache'
SHAPES=[('Q',1024,2048,28),('K_V',1024,1024,56),('O',2048,1024,28),('GATE_UP',1024,3072,56),('DOWN',3072,1024,28)]
BITS=[8,4,2]
STAGES=['load_x','generate_brams','load_w_and_select','store_o']
TOOLS=Path(os.environ.get('LUMIXED_TOOLS_PREFIX','/home/kioannou/chipyard_1.13.0/.conda-env'))
RUNTIME=Path(os.environ.get('LUMIXED_SOFT_RUNTIME','/tmp/lumixed-1.15-validation/soft-runtime/riscv64-unknown-elf/lib'))
FIRTOOL=Path('/home/kioannou/.local/opt/firtool-1.75.0/bin/firtool')

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(p)

def table(p,rows):
 if not rows:return
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)

def run(cmd,log,env,cwd=CY,timeout=None):
 log.parent.mkdir(parents=True,exist_ok=True)
 save(log.with_suffix('.command.json'),list(map(str,cmd)))
 with log.open('wb') as f:
  try:r=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
  except subprocess.TimeoutExpired:raise RuntimeError(f'Timeout: {log}')
 if r.returncode:raise RuntimeError(f'Exit {r.returncode}: {log}; '+log.read_bytes()[-1800:].decode(errors='replace'))

def environment():
 env=os.environ.copy();env.pop('USE_CHISEL7',None)
 env['RISCV']=str(TOOLS/'riscv-tools')
 env['PATH']=f'{FIRTOOL.parent}:{TOOLS}/bin:{TOOLS}/riscv-tools/bin:'+env.get('PATH','')
 env['LD_LIBRARY_PATH']=f'{TOOLS}/lib:{TOOLS}/riscv-tools/lib:'+env.get('LD_LIBRARY_PATH','')
 tmp=Path('/tmp')/f'lmxus-{os.getuid()}';tmp.mkdir(mode=0o700,exist_ok=True)
 env['XDG_RUNTIME_DIR']=str(tmp)
 env['JAVA_TOOL_OPTIONS']=f'-Xmx8G -Xss8M -XX:ActiveProcessorCount=2 -Djava.io.tmpdir={tmp}'
 env['SBT_OPTS']='-Dsbt.ivy.home=/home/kioannou/.ivy2 -Dsbt.global.base=/home/kioannou/.sbt -Dsbt.boot.directory=/home/kioannou/.sbt/boot -Dsbt.supershell=false -Dsbt.server.forcestart=false -Dsbt.task.cpus=2'
 env['MAKEFLAGS']='-j1';env['PYTHONDONTWRITEBYTECODE']='1'
 for k,v in [('CC','gcc'),('CXX','c++')]:
  p=TOOLS/'bin'/f'x86_64-conda-linux-gnu-{v}'
  if p.exists():env[k]=str(p)
 return env

def source_files():
 return [CY/'build.sbt',CY/'project/build.properties',CY/'project/plugins.sbt',HERE/'harness.c',HERE/'run_benchmark.py',
  *sorted((CY/'generators/LUMIXED/src/main/scala').glob('*.scala')),
  *[CY/'generators/LUMIXED/software/tests/src'/n for n in ['lumixed_api.h','lumixed_rocc.h','rocc.h','prepare_test_vectors.py']]]

def check_sources(manifest):
 for p,h in manifest.items():
  if not Path(p).exists() or sha(p)!=h:raise RuntimeError(f'Source changed while batch active: {p}')

def reference_module():
 p=CACHE/'snapshot/prepare_test_vectors.py';spec=importlib.util.spec_from_file_location('exact_fp_reference',p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m

def setup(env,manifest):
 snap=CACHE/'snapshot';snap.mkdir(parents=True,exist_ok=True)
 for p in source_files():
  if p.name in ('lumixed_api.h','lumixed_rocc.h','rocc.h','prepare_test_vectors.py','harness.c'):shutil.copyfile(p,snap/p.name)
 for p in [TOOLS/'bin/java',TOOLS/'bin/verilator',TOOLS/'riscv-tools/bin/riscv64-unknown-elf-gcc',FIRTOOL,RUNTIME/'libc.a',RUNTIME/'libgloss_htif.a']:
  if not p.exists():raise RuntimeError(f'Missing tool/runtime: {p}')
 jars=CACHE/'classpath';jars.mkdir(exist_ok=True)
 if not (jars/'source_hashes.json').exists() or json.loads((jars/'source_hashes.json').read_text())!=manifest or not (jars/'chipyard.jar').exists():
  print('ASSEMBLING CURRENT CHIPYARD RTL (ABI v2)',flush=True)
  cmd=['make','-C',CY/'sims/verilator','-j2','CONFIG=LUMIXEDRocketConfig','NUMACTL=0',f'CLASSPATH_CACHE={jars}',jars/'chipyard.jar']
  run(cmd,CACHE/'assembly.log',env)
  save(jars/'source_hashes.json',manifest)
 if not (jars/'tapeout.jar').exists() or not zipfile.is_zipfile(jars/'tapeout.jar'):
  # MacroCompiler is a tool, not accelerator RTL. Reuse the verified 1.15 tool
  # assembly; its sources have not changed since the first 1.15 build.
  tool_jar=Path('/tmp/lumixed-1.15-validation/classpath/tapeout.jar')
  if not zipfile.is_zipfile(tool_jar):raise RuntimeError('Missing valid Chipyard 1.15 MacroCompiler tapeout.jar')
  if subprocess.check_output(['git','diff','d7ff25e1','--','tools/tapeout'],cwd=CY):raise RuntimeError('MacroCompiler sources changed; rebuild its tool jar explicitly')
  shutil.copyfile(tool_jar,jars/'tapeout.jar')
  save(jars/'tapeout_tool_provenance.json',dict(source=str(tool_jar),sha256=sha(tool_jar),basis='Unchanged Chipyard 1.15 MacroCompiler sources; not accelerator RTL'))
 check_sources(manifest)
 return jars

def compiler_jars():
 result=[]
 for n in ['scala-compiler','scala-library','scala-reflect']:
  matches=list((Path.home()/'.cache/coursier').glob(f'**/{n}/2.13.16/{n}-2.13.16.jar'))
  if not matches:raise RuntimeError(f'Missing Scala compiler dependency: {n} 2.13.16')
  result.append(matches[0])
 return result

def build_sim(config,mode,jars,manifest,env):
 scaled=mode=='scaled';params=dict(config,mode=mode,GROUP_SCALE_DEFERRED=scaled,GROUP_SCALE_ALIGNED=False,FP_BITS=32,DMA_Bytes=8,W_BUFFS=2,MAX_K=3072,MAX_N=3072,source_hashes={p:h for p,h in manifest.items() if p.endswith(('.scala','.sbt','.properties'))},base_jar_sha256=sha(jars/'chipyard.jar'))
 key=hashlib.sha256(json.dumps(params,sort_keys=True).encode()).hexdigest()[:16]
 build=CACHE/'build'/f"{config['design']}_{mode}_{key}";build.mkdir(parents=True,exist_ok=True)
 sim=build/'sim/simulator-current-QwenCompareRocketConfig'
 if (build/'complete.json').exists() and sim.exists() and json.loads((build/'complete.json').read_text())['simulator_sha256']==sha(sim):return sim,build
 save(build/'parameters.json',params)
 scala=build/'QwenCompareRocketConfig.scala';scala.write_text(f'''package qwencompare
import org.chipsalliance.cde.config.Config
class QwenCompareRocketConfig extends Config(
 new Config((site,here,up) => {{
  case LUMIXED_PACKAGE.LUMIXEDParamsKey => LUMIXED_PACKAGE.LUMIXED_Config.LUMIXED_Config.copy(
   Rin=4,Cin=3072,Cout=3072,banks_per_row={config['B']},table_capacity_factor={config['RF']},parallel_rows={config['YS']},
   FP_ACTIVATIONS=true,FP_BITS=32,WBitWidth=8,OutBitWidth=32,DMA_Bytes=8,Dma_Ids={config['DMA_ID']},W_BUFFS=2,
   BRAM_OUTPUTS=true,GROUP_SCALE_ALIGNED=false,GROUP_SCALE_DEFERRED={str(scaled).lower()},DEBUG=true,
   SKIP_ZERO_WEIGHTS=false,FLEXIBLE_BANK_GROUPING=false,WEIGHT_DMA_BURSTS=false,EARLY_WEIGHT_BUFFER_RELEASE=false)
 }}) ++ new chipyard.LUMIXEDRocketConfig)
''')
 classes=build/'classes';classes.mkdir(exist_ok=True)
 print('BUILD',config['design'],mode,flush=True)
 run(['java','-cp',':'.join(map(str,compiler_jars())),'scala.tools.nsc.Main','-classpath',jars/'chipyard.jar','-d',classes,scala],build/'scala.log',env,build)
 jar=build/'generator.jar';shutil.copyfile(jars/'chipyard.jar',jar)
 with zipfile.ZipFile(jar,'a',compression=zipfile.ZIP_DEFLATED) as z:
  for p in classes.rglob('*.class'):z.write(p,str(p.relative_to(classes)))
 dram=build/'dramsim';dram.mkdir(exist_ok=True)
 for p in (CY/'tools/DRAMSim2').iterdir():
  if p.is_file() and (p.suffix in ('.h','.a','.so') or '.so.' in p.name):shutil.copyfile(p,dram/p.name)
 if not (dram/'libdramsim.a').exists():raise RuntimeError('Missing prebuilt DRAMSim2 library')
 sim.parent.mkdir(exist_ok=True)
 cmd=['make','-f',CY/'sims/verilator/Makefile','-j2',f'base_dir={CY}',f'sim_dir={sim.parent}',f'sim={sim}',
 'CONFIG=QwenCompareRocketConfig','CONFIG_PACKAGE=qwencompare',f'GENERATOR_CLASSPATH={jar}',f'TAPEOUT_CLASSPATH={jars}/tapeout.jar',
 f'dramsim_dir={dram}',f'dramsim_lib={dram}/libdramsim.a','SBT=/bin/false','CHIPYARD_SCALA_SOURCES=','CHIPYARD_VLOG_SOURCES=',
 'TAPEOUT_SCALA_SOURCES=','TAPEOUT_VLOG_SOURCES=','SCALA_BUILDTOOL_DEPS=','SBT_SOURCES=','NUMACTL=0','-o',jars/'tapeout.jar','default']
 run(cmd,build/'build.log',env,sim.parent)
 # Unscaled group-processing logic must be absent, rather than fed unity scales.
 if not scaled:
  collateral=next((sim.parent/'generated-src').glob('*/gen-collateral'))
  for p in collateral.glob('*.sv'):
   text=p.read_text(errors='replace')
   if re.search(r'\bmodule\s+GroupScaleEngine\b',text):raise RuntimeError('Unscaled RTL unexpectedly contains GroupScaleEngine')
 save(build/'complete.json',dict(simulator_sha256=sha(sim),group_scale_engine_expected=scaled))
 return sim,build

def data_source(bits,k,n):
 p=CY/f'generators/LUMIXED/software/QWEN_VERIFY/cache/synthetic_qwen_shapes_R4/Q{bits}_0/R4_K{k}_N{n}'
 if not (p/'activations.f32.bin').exists():raise RuntimeError(f'Original synthetic inputs unavailable: {p}; refusing silent regeneration')
 return p

def prepare_data(bits,k,n,mode,smoke,ref):
 # Cache one reference per shape/mode; reuse identical values for every design.
 source=data_source(bits,1024 if smoke else k,1024 if smoke else n)
 oldk,oldn=(1024,1024) if smoke else (k,n)
 inp=source/'activations.f32.bin';weight=source/'weights.lumixed.sint.bin';sc=source/'scales.fp16.bin'
 hashes=dict(input_sha256=sha(inp),weights_sha256=sha(weight))
 if mode=='scaled':hashes['scales_sha256']=sha(sc)
 key=hashlib.sha256(json.dumps(dict(bits=bits,k=k,n=n,mode=mode,smoke=smoke,hashes=hashes,reference_sha256=sha(CACHE/'snapshot/prepare_test_vectors.py')),sort_keys=True).encode()).hexdigest()[:16]
 dst=CACHE/'vectors'/key;dst.mkdir(parents=True,exist_ok=True)
 if (dst/'complete.json').exists():
  saved=json.loads((dst/'complete.json').read_text())
  files={'input.bin':'input_sha256','weights.bin':'weights_sha256','expected.bin':'expected_sha256'}
  if mode=='scaled':files['scales.bin']='scales_sha256'
  if not all((dst/f).is_file() and sha(dst/f)==saved[h] for f,h in files.items()):raise RuntimeError(f'Cached reference/vector hashes changed: {dst}')
  return dst,saved
 xb=inp.read_bytes();wb=weight.read_bytes();x=b''.join(xb[r*oldk*4:r*oldk*4+k*4] for r in range(4))
 weights=b''.join(wb[col*oldk*bits//8:col*oldk*bits//8+k*bits//8] for col in range(n))
 assert len(x)==4*k*4 and len(weights)==k*n*bits//8
 (dst/'input.bin').write_bytes(x);(dst/'weights.bin').write_bytes(weights)
 group=64 if bits==2 else 32;scales=None
 if mode=='scaled':
  raw=sc.read_bytes();scales=b''.join(raw[g*oldn*2:g*oldn*2+n*2] for g in range((k+group-1)//group));(dst/'scales.bin').write_bytes(scales+b'\0'*(-len(scales)%8))
 acts=[[ref.fp_fixed(v[0],32) for v in struct.iter_unpack('<I',x[r*k*4:(r+1)*k*4])] for r in range(4)]
 sb=[v[0] for v in struct.iter_unpack('<H',scales)] if scales else None
 expected=[0]*(4*n);per_byte=8//bits;mask=(1<<bits)-1
 for col in range(n):
  colweights=weights[col*k*bits//8:(col+1)*k*bits//8]
  qw=[]
  for kk in range(k):
   v=(colweights[kk//per_byte]>>((kk%per_byte)*bits))&mask;qw.append(v-(1<<bits) if v&(1<<(bits-1)) else v)
  for r in range(4):
   if mode=='unscaled':value=sum(a*w for a,w in zip(acts[r],qw));frac=149
   else:
    value=sum(sum(acts[r][kk]*qw[kk] for kk in range(g,min(g+group,k)))*ref.fp16_fixed24(sb[(g//group)*n+col]) for g in range(0,k,group));frac=173
   expected[r*n+col]=ref.fixed_to_fp32_bits(value,frac)
 (dst/'expected.bin').write_bytes(struct.pack('<'+'I'*len(expected),*expected))
 meta=dict(input_sha256=sha(dst/'input.bin'),weights_sha256=sha(dst/'weights.bin'),expected_sha256=sha(dst/'expected.bin'),source=str(source),input_equivalence='ORIGINAL_BYTES' if not smoke else 'ORIGINAL_CROP',group_size=group if mode=='scaled' else 0)
 if mode=='scaled':meta['scales_sha256']=sha(dst/'scales.bin')
 # Establish equivalence against the archive's per-test recorded hashes.
 if not smoke:
  archive_log=next((ARCHIVE/'logs').glob('*/verilator.log')).read_text()
  target=archive_log.split(f'W{bits} ',1)[1] if False else archive_log
  assert f"Input SHA256: {meta['input_sha256']}" in target and f"Packed weights SHA256: {meta['weights_sha256']}" in target,'Inputs do not match archived evidence'
 save(dst/'complete.json',meta);return dst,meta

def execute(config,mode,shape,bits,sim,build,ref,env,smoke=False):
 name,k,n,count=shape
 if smoke:k,n=32,4
 folder=OUTPUT/('smoke' if smoke else 'logs')/config['design']/mode/f'W{bits}_{name}'
 folder.mkdir(parents=True,exist_ok=True)
 vec,meta=prepare_data(bits,k,n,mode,smoke,ref)
 key=dict(config=config,mode=mode,shape=[4,k,n],bits=bits,inputs=meta,simulator_sha256=sha(sim),harness_sha256=sha(CACHE/'snapshot/harness.c'))
 complete=folder/'result.json'
 if complete.exists():
  old=json.loads(complete.read_text())
  if old.get('cache_key')==key and old.get('result')=='PASS' and (folder/'output.bin').exists() and (folder/'output.bin').read_bytes()==(vec/'expected.bin').read_bytes():return old
 row=dict(design=config['design'],mode=mode,projection=name,R=4,K=k,N=n,weight_bits=bits,occurrences=count,result='FAIL',cache_key=key,**meta)
 print('RUN',config['design'],mode,f'W{bits}',f'4x{k}x{n}',flush=True)
 try:
  for src,dst in [('input.bin','input.bin'),('weights.bin','weights.bin')]:shutil.copyfile(vec/src,folder/dst)
  # The reference is not linked into the test ELF, only input/weight/optional scale bytes.
  asm=['.section .rodata.vectors,"a",@progbits']
  entries=[('bench_x','input.bin'),('bench_w','weights.bin')]
  if mode=='scaled':shutil.copyfile(vec/'scales.bin',folder/'scales.bin');entries.append(('bench_scales','scales.bin'))
  for label,file in entries:asm+=['.balign 8',f'.global {label}',f'{label}:',f'.incbin "{file}"']
  asm+=['.section .note.GNU-stack,"",@progbits'];(folder/'vectors.S').write_text('\n'.join(asm)+'\n')
  for fn in ['harness.c','lumixed_api.h','lumixed_rocc.h','rocc.h']:shutil.copyfile(CACHE/'snapshot'/fn,folder/fn)
  gcc=TOOLS/'riscv-tools/bin/riscv64-unknown-elf-gcc'
  defines=dict(RIN_MAX=4,CIN_MAX=k,COUT_MAX=n,W_BITS=bits,banks_per_row=config['B'],parallel_rows=config['YS'],table_capacity_factor=config['RF'],LUMIXED_GROUP_SCALE_MODE=2 if mode=='scaled' else 0)
  if mode=='scaled':defines['GROUP_SIZE']=meta['group_size']
  cmd=[gcc,'-O2','-march=rv64imac_zicsr_zifencei','-mabi=lp64','-mcmodel=medany','-ffunction-sections','-fdata-sections','-fno-builtin-printf','-fno-common',*[f'-D{a}={v}' for a,v in defines.items()],f'-I{RUNTIME.parent}/include','-nostdlib','-static','harness.c','vectors.S','-Wl,--gc-sections',f'-Wl,-T,{RUNTIME}/htif.ld','-Wl,--start-group',RUNTIME/'libc.a',RUNTIME/'libgloss_htif.a','-lgcc','-Wl,--end-group','-o','test.riscv']
  run(cmd,folder/'compile.log',env,folder)
  if mode=='unscaled':
   sym=subprocess.check_output([TOOLS/'riscv-tools/bin/riscv64-unknown-elf-nm',folder/'test.riscv'],text=True)
   if 'bench_scales' in sym:raise RuntimeError('Scale array linked into unscaled ELF')
  cmd=[sim,'+permissive','+max-cycles=1000000000',f'+loadmem={folder}/test.riscv','+permissive-off',folder/'test.riscv']
  started=time.monotonic();run(cmd,folder/'verilator.raw.log',env,folder,7200);row['elapsed_seconds']=time.monotonic()-started;row['simulator_exit']=0
  raw=(folder/'verilator.raw.log').read_bytes();marker=f'BENCH_BINARY {4*n*4}\n'.encode();pos=raw.find(marker)
  if pos<0 or b'BENCH_GUARDS PASS' not in raw:raise RuntimeError('Missing output or failed guards')
  pos+=len(marker);payload=raw[pos:pos+4*n*4]
  if not raw[pos+4*n*4:].startswith(b'\nBENCH_END\n'):raise RuntimeError('Output payload truncated')
  (folder/'output.bin').write_bytes(payload);expected=(vec/'expected.bin').read_bytes();shutil.copyfile(vec/'expected.bin',folder/'expected.bin')
  got=list(struct.unpack('<'+'I'*(4*n),payload));exp=list(struct.unpack('<'+'I'*(4*n),expected));bad=[i for i,(a,b) in enumerate(zip(got,exp)) if a!=b]
  row.update(elements=4*n,exact_matches=4*n-len(bad),bit_mismatches=len(bad),guards='PASS',output_sha256=sha(folder/'output.bin'),elf_sha256=sha(folder/'test.riscv'),raw_log_sha256=sha(folder/'verilator.raw.log'))
  if bad:raise RuntimeError(f'{len(bad)} bit mismatches; first index {bad[0]} got={got[bad[0]]:08x} expected={exp[bad[0]]:08x}')
  m=re.search(rb'BENCH_CYCLES total=(\d+) load_x=(\d+) generate_brams=(\d+) load_w=(\d+) select_accumulate=(\d+) store_o=(\d+) load_w_and_select=(\d+)',raw)
  if not m:raise RuntimeError('Missing hardware cycle counters')
  row['cycles']=dict(zip(['total','load_x','generate_brams','load_w','select_accumulate','store_o','load_w_and_select'],map(int,m.groups())))
  if row['cycles']['total']!=sum(row['cycles'][x] for x in STAGES):raise RuntimeError('Cycle total does not sum')
  row['result']='PASS'
 except Exception as e:row['error']=str(e)
 save(folder/'result.json',row);print(row['result'],row.get('cycles',{}).get('total'),row.get('error',''),flush=True)
 return row

def summarize(configs,manifest):
 rows=[]
 for p in (OUTPUT/'logs').glob('*/*/*/result.json'):
  row=json.loads(p.read_text());rows.append(row)
 flat=[]
 for r in sorted(rows,key=lambda x:(x['design'],x['mode'],-x['weight_bits'],x['projection'])):
  flat.append(dict(design=r['design'],mode=r['mode'],projection=r['projection'],weight_bits=r['weight_bits'],R=r['R'],K=r['K'],N=r['N'],occurrences=r['occurrences'],group_size=r['group_size'],result=r['result'],elements=r.get('elements',r['R']*r['N']),exact_matches=r.get('exact_matches',0),bit_mismatches=r.get('bit_mismatches',''),simulator_exit=r.get('simulator_exit',''),**{k:r.get('cycles',{}).get(k,'') for k in ['load_x','generate_brams','load_w','select_accumulate','load_w_and_select','store_o','total']},input_sha256=r['input_sha256'],weights_sha256=r['weights_sha256'],expected_sha256=r['expected_sha256'],output_sha256=r.get('output_sha256',''),error=r.get('error','')))
 table(OUTPUT/'matmul_cycles.csv',[r for r in flat if r['mode']=='unscaled'])
 table(OUTPUT/'matched_scaled_matmul_cycles.csv',[r for r in flat if r['mode']=='scaled'])
 estimates=[];lookup={}
 for c in configs:
  for mode in ['unscaled','scaled']:
   for bits in BITS:
    rr=[r for r in rows if r['design']==c['design'] and r['mode']==mode and r['weight_bits']==bits and r['result']=='PASS']
    if len(rr)!=5:continue
    val=dict(design=c['design'],mode=mode,R=4,weight_bits=bits,projection_calls=196,estimated_cycles=sum(r['occurrences']*r['cycles']['total'] for r in rr),**{s:sum(r['occurrences']*r['cycles'][s] for r in rr) for s in STAGES})
    estimates.append(val);lookup[c['design'],mode,bits]=val
 table(OUTPUT/'projection_estimates.csv',[r for r in estimates if r['mode']=='unscaled'])
 table(OUTPUT/'matched_scaled_projection_estimates.csv',[r for r in estimates if r['mode']=='scaled'])
 old_matmuls=list(csv.DictReader((ARCHIVE/'matmul_cycles.csv').open()))
 old_cases={(r['design'],int(r['weight_bits']),r['projection']):r for r in old_matmuls}
 old=list(csv.DictReader((ARCHIVE/'projection_estimates.csv').open()));oldmap={(r['design'],int(r['weight_bits'])):int(r['estimated_cycles']) for r in old}
 comparison=[];individual=[]
 for c in configs:
  for bits in BITS:
   u=lookup.get((c['design'],'unscaled',bits));s=lookup.get((c['design'],'scaled',bits))
   if u and s:comparison.append(dict(configuration=c['design'],precision=f'W{bits}',scaled_cycles=s['estimated_cycles'],unscaled_cycles=u['estimated_cycles'],scaling_overhead_percent=100*(s['estimated_cycles']/u['estimated_cycles']-1),comparison_basis='CURRENT_REVISION_MATCHED_HARNESS',archived_scaled_cycles=oldmap[c['design'],bits],current_scaled_vs_archived_percent=100*(s['estimated_cycles']/oldmap[c['design'],bits]-1)))
   for name,_,_,_ in SHAPES:
    pair=[r for r in rows if r['design']==c['design'] and r['weight_bits']==bits and r['projection']==name and r['result']=='PASS']
    dd={r['mode']:r for r in pair}
    if len(dd)!=2:continue
    u,s=dd['unscaled'],dd['scaled']
    assert u['input_sha256']==s['input_sha256'] and u['weights_sha256']==s['weights_sha256']
    historical=old_cases[c['design'],bits,name]
    individual.append(dict(configuration=c['design'],precision=f'W{bits}',projection=name,scaled_cycles=s['cycles']['total'],unscaled_cycles=u['cycles']['total'],scaling_overhead_percent=100*(s['cycles']['total']/u['cycles']['total']-1),input_hashes_equal=True,weight_hashes_equal=True,archived_scaled_cycles=int(historical['total']),current_scaled_vs_archived_percent=100*(s['cycles']['total']/int(historical['total'])-1)))
 table(OUTPUT/'scaled_vs_unscaled.csv',comparison);table(OUTPUT/'scaled_vs_unscaled_matmuls.csv',individual)
 cfg=[]
 for c in configs:
  for mode in ['unscaled','scaled']:
   cfg.append(dict(c,mode=mode,FP_ACTIVATIONS=True,FP_BITS=32,OutBitWidth=32,WBitWidth=8,minWeightBits=2,minInputBits=8,INT_BITS=16,num_filters=1,Rin=4,Cin=3072,Cout=3072,DMA_Bytes=8,W_BUFFS=2,BRAM_OUTPUTS=True,GROUP_SCALE_DEFERRED=mode=='scaled',GROUP_SCALE_ALIGNED=False,SKIP_ZERO_WEIGHTS=False,FLEXIBLE_BANK_GROUPING=False,EARLY_WEIGHT_BUFFER_RELEASE=False,WEIGHT_DMA_BURSTS=False,MAX_WEIGHT_BURST_BYTES=32,DEBUG=True,legacy_SCALE='REMOVED_FROM_CURRENT_RTL_NO_INTEGER_SCALING'))
 table(OUTPUT/'configurations.csv',cfg)
 un=[r for r in rows if r['mode']=='unscaled'];scaled=[r for r in rows if r['mode']=='scaled']
 status=dict(unscaled_pass=sum(r['result']=='PASS' for r in un),unscaled_completed=len(un),unscaled_expected=120,unscaled_exact_matches=sum(r.get('exact_matches',0) for r in un),scaled_pass=sum(r['result']=='PASS' for r in scaled),scaled_completed=len(scaled),scaled_expected=120,scaled_exact_matches=sum(r.get('exact_matches',0) for r in scaled),failures=[{k:r.get(k) for k in ['design','mode','projection','weight_bits','error']} for r in rows if r['result']!='PASS'])
 save(OUTPUT/'status.json',status)
 lines=['# Qwen-shaped scaling OFF/ON comparison','',f"Unscaled exact-reference passes: **{status['unscaled_pass']}/120** ({status['unscaled_exact_matches']:,} elements). Matching current-RTL scaled passes: **{status['scaled_pass']}/120**.",'', 'These are synthetic Qwen3-0.6B-shaped GEMMs at R=4, not Qwen inference. Historical scaled results are read-only. The current RoCC ABI and initialization state differ from the archive; only same-revision, same-harness scaled reruns define the scaling-overhead percentages below.','', '## Estimated 196 projection cycles','', '| Configuration | Precision | Current scaled | Unscaled | Scaling overhead % |','|---|---|---:|---:|---:|']
 for r in comparison:lines.append(f"| {r['configuration']} | {r['precision']} | {r['scaled_cycles']:,} | {r['unscaled_cycles']:,} | {r['scaling_overhead_percent']:.3f} |")
 if not comparison:lines.append('| Pending measurements | — | — | — | — |')
 lines+=['','Overhead = 100 × (scaled / unscaled − 1). These are measured controller cycles with an identical memory model; bus/cache stalls can make stage costs non-monotonic. No frequency or power assumptions are applied.','', 'Estimate = 28×Q + 56×K/V + 28×O + 56×Gate/Up + 28×Down; excludes attention, head, RoPE, norms and non-GEMM operations. No unmeasured shape is extrapolated.','', '## Best unscaled configuration and bottlenecks','']
 for bits in BITS:
  rr=[r for r in estimates if r['mode']=='unscaled' and r['weight_bits']==bits]
  if rr:
   best=min(rr,key=lambda r:r['estimated_cycles']);stage=max(STAGES,key=lambda s:best[s]);lines.append(f"- W{bits}: {best['design']}, {best['estimated_cycles']:,} projection cycles; largest stage {stage}: {100*best[stage]/best['estimated_cycles']:.2f}%. Best among {len(rr)}/8 measured configurations.")
 lines+=['','## Individual measured matmuls','', '| Configuration | Mode | Precision | Shape R×K×N | PASS | Load X | Generate | Load W + select | Store O | Total |','|---|---|---|---|---|---:|---:|---:|---:|---:|']
 for r in flat:lines.append(f"| {r['design']} | {r['mode']} | W{r['weight_bits']} | {r['R']}×{r['K']}×{r['N']} | {r['result']} | {r['load_x']} | {r['generate_brams']} | {r['load_w_and_select']} | {r['store_o']} | {r['total']} |")
 lines+=['','## Evidence and measurement method','', '- `matmul_cycles.csv` / `projection_estimates.csv`: unscaled measurements / estimates.','- `matched_scaled_*.csv`: same-current-revision scaled control measurements.','- `scaled_vs_unscaled*.csv`: matched overhead per projection set and individual matmul; historical totals remain explicitly labelled.','- `logs/<configuration>/<mode>/<case>/`: original binary Verilator log, exact verification result, output payload, expected bits, input bytes, optional scaled-only scales, commands and C snapshots.','- `provenance.json`: current source hashes, commit, tool versions, build cache links and unchanged-source policy.','- `cache/build/*/parameters.json` and `QwenCompareRocketConfig.scala` under the suite: exact elaboration settings; separate scaled/unscaled caches.','', 'Every FP32 activation is decoded to an arbitrary-precision integer times 2^-149. Unscaled output rounds the exact signed sum once to FP32 RNE. Scaled controls use exact FP16 scale values times 2^-24 and round the final exact sum in 2^-173 units. No host FP32 running sum is used.','', 'Counters are read after wait_done. Total = load_x + generate_brams + load_w_and_select + store_o; load_w and select_accumulate overlap and are diagnostic only. This is the same controller-counter boundary used by the archive, with the current ABI/harness identical across both modes.','', 'The legacy integer SCALE parameter was removed by the current source refactor. It is absent, not reintroduced or enabled. Unscaled RTL sets both group flags false, excludes GroupScaleEngine, requires G=0, starts with NULL, links no scale array and bypasses the scale-load state through elaboration conditionals. No scale=1 emulation is used.','', 'Original synthetic input/weight bytes are reused for every configuration. Hashes must match archived log evidence. Current matching scaled controls use the original FP16 scale bytes.','', '## Reproduce','', '```bash','cd /home/kioannou/chipyard_1.15.0/generators/LUMIXED/software/QWEN_UNSCALED_VERIFY','bash run.sh start','bash run.sh status','```','', 'Two CPU cores, nice priority, sequential simulator builds/runs. `start` detaches from SSH. Current source changes stop the worker to avoid mixed revisions. A rerun rechecks cache provenance and reuses only exact matching completed cases. Original archives and RTL/software API files are never rewritten.','']
 if status['failures']:lines+=['## Failures',json.dumps(status['failures'],indent=2)]
 (OUTPUT/'README.md').write_text('\n'.join(lines)+'\n')
 return status

def worker():
 CACHE.mkdir(parents=True,exist_ok=True);OUTPUT.mkdir(parents=True,exist_ok=True)
 lock=(CACHE/'worker.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
 (CACHE/'worker.pid').write_text(str(os.getpid()))
 if (OUTPUT/'worker_error.json').exists():
  (OUTPUT/'worker_error.json').rename(OUTPUT/f'previous_worker_error_{datetime.datetime.now():%Y%m%d_%H%M%S}.json')
 manifest={str(p):sha(p) for p in source_files()};env=environment()
 configs=[]
 for c in csv.DictReader((ARCHIVE/'configurations.csv').open()):
  assert c['activation']=='FP32' and c['DMA_Bytes']=='8' and c['W_BUFFS']=='2'
  configs.append(dict(design=c['design'],B=int(c['B']),RF=int(c['RF']),YS=int(c['YS']),DMA_ID=int(c['DMA_ID'])))
 assert len(configs)==8
 jars=setup(env,manifest);ref=reference_module()
 save(OUTPUT/'provenance.json',dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=CY,text=True).strip(),source_hashes=manifest,current_jar_sha256=sha(jars/'chipyard.jar'),legacy_baseline='pre-API/RoCC refactor; historical data only',arithmetic='unscaled sum X*W rounded once; scaled controls exact sum of group sums * FP16 scales',tools={k:subprocess.check_output(v,env=env,stderr=subprocess.STDOUT,text=True).strip() for k,v in {'verilator':['verilator','--version'],'firtool':['firtool','--version'],'compiler':[str(TOOLS/'riscv-tools/bin/riscv64-unknown-elf-gcc'),'--version']}.items()}))
 summarize(configs,manifest)
 # Require smoke W8/W4/W2 for both modes before any full-sized case.
 sims={}
 for mode in ['unscaled','scaled']:
  check_sources(manifest);sim,build=build_sim(configs[0],mode,jars,manifest,env);sims[configs[0]['design'],mode]=(sim,build)
  for bits in BITS:
   r=execute(configs[0],mode,('K_V',32,4,56),bits,sim,build,ref,env,True)
   if r['result']!='PASS':raise RuntimeError('Smoke failed; full batch not started: '+str(r.get('error')))
 print('SMOKE PASS: 6/6, including 3 unscaled precisions',flush=True)
 for config in configs:
  for mode in ['unscaled','scaled']:
   check_sources(manifest);sim,build=sims.get((config['design'],mode),(None,None))
   if sim is None:sim,build=build_sim(config,mode,jars,manifest,env)
   for bits in BITS:
    for shape in SHAPES:
     check_sources(manifest);execute(config,mode,shape,bits,sim,build,ref,env);summarize(configs,manifest)
  print('DESIGN COMPLETE',config['design'],flush=True)
 state=summarize(configs,manifest)
 if state['unscaled_pass']==120 and state['scaled_pass']==120 and not state['failures']:
  save(OUTPUT/'completed.json',state);print('COMPLETE: UNSCALED 120/120; MATCHED SCALED 120/120',flush=True)
 else:raise RuntimeError('Batch incomplete or failures; see status.json')

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['start','worker','status'],nargs='?',default='status');a=p.parse_args()
 if a.action=='start':
  CACHE.mkdir(parents=True,exist_ok=True)
  with (CACHE/'worker.lock').open('a') as f:
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError:sys.exit('Worker already active')
   with (HERE/'benchmark-console.log').open('ab') as log:
    proc=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'worker'],cwd=HERE,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  print('Started worker PID',proc.pid,'Log:',HERE/'benchmark-console.log')
 elif a.action=='worker':
  try:worker()
  except Exception as e:
   save(OUTPUT/'worker_error.json',dict(error=str(e),time=datetime.datetime.now().isoformat()));raise
 else:
  if (OUTPUT/'status.json').exists():print((OUTPUT/'status.json').read_text())
  if (OUTPUT/'worker_error.json').exists():print('WORKER ERROR:',(OUTPUT/'worker_error.json').read_text())
  if (CACHE/'worker.pid').exists():
   pid=int((CACHE/'worker.pid').read_text());print('Worker PID',pid,'process present:',Path(f'/proc/{pid}').exists())
  else:print('Not started')

if __name__=='__main__':main()
