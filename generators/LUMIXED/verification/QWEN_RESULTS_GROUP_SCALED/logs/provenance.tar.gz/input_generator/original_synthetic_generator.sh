#!/usr/bin/env bash
# Qwen3-0.6B SHAPE benchmark (not actual GGUF values).
# Reuses QWEN_VERIFY/run_qwen_verify.py and summarize.py without modifying them.
# Runs W8/W4/W2, R=4, 5 projection shapes, eight B/RF/YS/DMA-ID configs.
set -uo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE" || exit 1
[[ -f run_qwen_verify.py && -f run.sh && -f summarize.py ]] || {
  echo 'Put this script in generators/LUMIXED/software/QWEN_VERIFY/' >&2
  exit 1
}

DATA="$HERE/cache/synthetic_qwen_shapes_R4"
RUNNER="$HERE/_run_qwen_synthetic.py"
mkdir -p "$DATA"

# Generate one repeatable, explicitly SYNTHETIC capture package. It has the
# same binary layout as a normal capture, but intentionally NO llama.cpp output.
python3 - "$DATA" <<'PY'
import json
import random
import struct
import sys
from pathlib import Path

root = Path(sys.argv[1])
shapes = ((1024, 2048), (1024, 1024), (2048, 1024),
          (1024, 3072), (3072, 1024))
for bits in (8, 4, 2):
    group = 64 if bits == 2 else 32
    # Powers of two: exactly representable FP16 per-group scales.
    scale_values = {8: (1/256, 1/128, 1/64),
                    4: (1/64, 1/32, 1/16),
                    2: (1/16, 1/8, 1/4)}[bits]
    for k, n in shapes:
        dest = root / f'Q{bits}_0' / f'R4_K{k}_N{n}'
        dest.mkdir(parents=True, exist_ok=True)
        expected = ('metadata.json', 'activations.f32.bin',
                    'weights.lumixed.sint.bin', 'scales.fp16.bin')
        if all((dest / p).exists() for p in expected):
            meta = json.loads((dest / 'metadata.json').read_text())
            if (meta.get('synthetic') is True and meta.get('K') == k
                    and meta.get('N') == n and meta.get('weight_bits') == bits
                    and (dest / 'activations.f32.bin').stat().st_size == 4*k*4
                    and (dest / 'weights.lumixed.sint.bin').stat().st_size == k*n*bits//8
                    and (dest / 'scales.fp16.bin').stat().st_size == (k//group)*n*2):
                continue
        rng = random.Random(20261118 + bits*100000 + k*37 + n)
        # Four independent, finite FP32 activation rows.
        with (dest / 'activations.f32.bin').open('wb') as f:
            for _ in range(4*k):
                f.write(struct.pack('<f', rng.randrange(-4096, 4097)/4096))
        # Uniform packed two's-complement signed W8/W4/W2, column-major.
        (dest / 'weights.lumixed.sint.bin').write_bytes(rng.randbytes(k*n*bits//8))
        # Group-major: each group contains N FP16 scales, one per output column.
        with (dest / 'scales.fp16.bin').open('wb') as f:
            for _ in range((k//group)*n):
                f.write(struct.pack('<e', rng.choice(scale_values)))
        (dest / 'metadata.json').write_text(json.dumps({
            'R':4,'K':k,'N':n,'weight_bits':bits,'group_size':group,
            'weight_format':f'SYNTHETIC_SIGNED_INT{bits}',
            'lumixed_compatible':True,'synthetic':True,
            'note':'Generated shape benchmark, not real Qwen3 weights or activations.'
        }, indent=2)+'\n')
        print(f'Generated synthetic W{bits} R4 K{k} N{n}', flush=True)
print('Synthetic capture package:', root, flush=True)
PY
rc=$?
(( rc == 0 )) || exit "$rc"

# Keep the real runner untouched. The only functional change in this local
# copy: native comparison is optional when no native output was supplied.
python3 - "$HERE/run_qwen_verify.py" "$RUNNER" <<'PY'
import sys
from pathlib import Path
src, dst = map(Path, sys.argv[1:])
code = src.read_text()
old = 'if k == oldk:'
new = 'if k == oldk and (source / "output.llamacpp.f32.bin").exists():'
if code.count(old) != 1:
    raise SystemExit('Original runner changed; cannot safely patch the native-output guard.')
code = code.replace(old, new, 1)
code = code.replace('not applicable (cropped smoke)', 'not applicable (no native output)', 1)
code = code.replace('Native outputs are unchanged captured llama.cpp outputs. A native difference is not silently accepted as an exact match.',
                    'Synthetic inputs only: no native llama.cpp outputs were used.', 1)
# Adapt only dependency locations and bare-metal linking for Cheetara.
# Keep the original reference, hardware geometry and execution path intact.
code = code.replace('conda = CY / ".conda-env"',
                    'conda = Path(os.environ.get("LUMIXED_TOOLS_PREFIX", "/home/kioannou/chipyard_1.13.0/.conda-env"))', 1)
code = code.replace('PATH=f"{conda}/bin:{conda}/riscv-tools/bin:"',
                    'PATH=f"/home/kioannou/.local/opt/firtool-1.75.0/bin:{conda}/bin:{conda}/riscv-tools/bin:"', 1)
code = code.replace('base = CY.parent / "cache" / "coursier"',
                    'base = Path.home() / ".cache" / "coursier"', 1)
code = code.replace('base_jar = CY / ".classpath_cache" / "chipyard.jar"',
                    'base_jar = Path(os.environ.get("LUMIXED_CHIPYARD_JAR", "/tmp/lumixed-1.15-validation/classpath/chipyard.jar"))', 1)
code = code.replace('tapeout = CY / ".classpath_cache" / "tapeout.jar"',
                    'tapeout = Path(os.environ.get("LUMIXED_TAPEOUT_JAR", "/tmp/lumixed-1.15-validation/classpath/tapeout.jar"))', 1)
start = code.index('    runtime = Path(env["RISCV"]) / "riscv64-unknown-elf/lib/rv64imac_zicsr_zifencei/lp64"')
end = code.index('    save(directory / "compile-command.json"', start)
code = code[:start] + '''    runtime = Path(os.environ.get("LUMIXED_SOFT_RUNTIME", "/tmp/lumixed-1.15-validation/soft-runtime/riscv64-unknown-elf/lib"))
    if not (runtime / "libgloss_htif.a").is_file():
        raise RuntimeError("Cheetara soft-float HTIF runtime is missing")
    cmd = [gcc, "-O2", "-march=rv64imac_zicsr_zifencei", "-mabi=lp64", "-mcmodel=medany",
           "-ffunction-sections", "-fdata-sections", "-fno-builtin-printf", "-fno-common",
           "-DLUMIXED_PREGENERATED_TEST=1", "-DLUMIXED_FP_ACTIVATIONS=1",
           "-DLUMIXED_FP_BITS=32", "-DLUMIXED_GROUP_SCALE_MODE=2", "-DLUMIXED_QUIET_TEST=0",
           f"-I{runtime.parent / 'include'}", "-nostdlib", "-static",
           "harness.c", "vectors.S", "atexit-workaround.c", "-Wl,--gc-sections",
           "-Wl,--wrap=atexit", f"-Wl,-T,{runtime / 'htif.ld'}", "-Wl,--start-group",
           runtime / "libc.a", runtime / "libgloss_htif.a", "-lgcc", "-Wl,--end-group", "-o", "verify.riscv"]
''' + code[end:]
# Use the existing summary code, with an accurate label for synthetic inputs.
summary_source = src.with_name("summarize.py")
summary_copy = dst.with_name("_summarize_qwen_synthetic.py")
summary_copy.write_text(summary_source.read_text().replace("real Qwen3 matmul results", "synthetic Qwen3-shaped matmul results"))
code = code.replace('summary_tool = HERE / "summarize.py"', 'summary_tool = HERE / "_summarize_qwen_synthetic.py"', 1)

dst.write_text(code)
PY
rc=$?
(( rc == 0 )) || exit "$rc"

[[ "${QWEN_PREPARE_ONLY:-0}" != 1 ]] || exit 0

JOBS="${QWEN_JOBS:-1}"
TIMEOUT="${QWEN_TIMEOUT:-7200}"
# Verify the adapter/linker and binary-output path before the long batch.
python3 "$RUNNER" smoke --b 8 --rf 8 --ys 2 --dma-ids 16 --r 4 \
  --weights 8 4 2 --captures "$DATA" --jobs "$JOBS" --timeout "$TIMEOUT"
rc=$?
(( rc == 0 )) || { echo "Smoke gate failed (exit $rc); batch not started." >&2; exit "$rc"; }
passed=0
failed=0
for ID in 8 16; do
  for config in "8 8 2" "4 4 4" "16 4 2" "8 4 4"; do
    read -r B RF YS <<< "$config"
    echo
    echo "======== SYNTHETIC Qwen shapes: B${B} RF${RF} YS${YS} ID${ID} R4 ========"
    python3 "$RUNNER" --b "$B" --rf "$RF" --ys "$YS" \
      --dma-ids "$ID" --r 4 --weights 8 4 2 --cases Q K_V O GATE_UP DOWN \
      --captures "$DATA" --jobs "$JOBS" --timeout "$TIMEOUT" </dev/null
    rc=$?
    if (( rc == 0 )); then
      ((passed+=1))
    else
      ((failed+=1))
      echo "FAILED: B${B}/RF${RF}/YS${YS}/ID${ID} (exit $rc)" >&2
    fi
  done
done

echo
printf 'Configurations passed: %d/8; failed: %d/8\n' "$passed" "$failed"
echo "Results: $HERE/runs/ (each run has summary.md and report.json)"
echo 'Reminder: measured controller cycles for synthetic Qwen-sized GEMMs, not end-to-end Qwen inference.'
(( failed == 0 ))
