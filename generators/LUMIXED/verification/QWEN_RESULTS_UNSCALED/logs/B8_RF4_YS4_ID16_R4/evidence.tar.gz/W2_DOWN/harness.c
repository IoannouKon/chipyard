// One identical ABI-v2 harness for current scaled/unscaled RTL builds.
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
typedef uint32_t input_t;
typedef int8_t weight_t;
typedef uint32_t output_t;
#define IN_BITS 32
#define LUMIXED_FP_ACTIVATIONS 1
#define LUMIXED_FP_BITS 32
#define LUMIXED_FLEXIBLE_BANK_GROUPING 0
int ACTIVATION_MAX_BITS=32, WEIGHTS_MAX_BITS=8;
int active_banks_per_row=banks_per_row, active_parallel_rows=parallel_rows;
unsigned long int_hw_cycles,float_hw_cycles,start,end;
#include "lumixed_api.h"
extern const input_t bench_x[RIN_MAX*CIN_MAX];
extern const weight_t bench_w[(CIN_MAX*COUT_MAX*W_BITS+7)/8];
#if LUMIXED_GROUP_SCALE_MODE
extern const uint16_t bench_scales[((CIN_MAX+GROUP_SIZE-1)/GROUP_SIZE)*COUT_MAX];
#endif
extern ssize_t _write(int,const void*,size_t);
_Alignas(8) static output_t guarded[RIN_MAX*COUT_MAX+4];
int main(void) {
 unsigned count=RIN_MAX*COUT_MAX;
 for(unsigned i=0;i<count+4;i++)guarded[i]=0xbadc0de;
 output_t *out=guarded+2;
 LumixedActivationTensor x={.q=(input_t*)bench_x};
 LumixedWeightTensor w={.q=(weight_t*)bench_w};
#if LUMIXED_GROUP_SCALE_MODE
 if(lumixed_set_group_scales(bench_scales,GROUP_SIZE))return 3;
#endif
 // In mode=0 the API emits G=0 and START with a NULL scale address.
 lumixed_configure_matmul(CIN_MAX,RIN_MAX,COUT_MAX,banks_per_row*table_capacity_factor,parallel_rows,x.q,w.q,out);
 lumixed_execute_matmul_timed(out,&x,&w,CIN_MAX,COUT_MAX,banks_per_row*table_capacity_factor,parallel_rows,RIN_MAX);
 unsigned long lx=lumixed_read_counter(LUMIXED_COUNTER_LOAD_X);
 unsigned long gen=lumixed_read_counter(LUMIXED_COUNTER_GENERATE);
 unsigned long lw=lumixed_read_counter(LUMIXED_COUNTER_LOAD_W);
 unsigned long sel=lumixed_read_counter(LUMIXED_COUNTER_SELECT);
 unsigned long so=lumixed_read_counter(LUMIXED_COUNTER_STORE_O);
 unsigned long both=lumixed_read_counter(LUMIXED_COUNTER_LOAD_W_AND_SELECT);
 int good=guarded[0]==0xbadc0de && guarded[1]==0xbadc0de && guarded[count+2]==0xbadc0de && guarded[count+3]==0xbadc0de;
 printf("BENCH_GUARDS %s\n",good?"PASS":"FAIL");
 printf("BENCH_CYCLES total=%lu load_x=%lu generate_brams=%lu load_w=%lu select_accumulate=%lu store_o=%lu load_w_and_select=%lu\n",lx+gen+both+so,lx,gen,lw,sel,so,both);
 printf("BENCH_BINARY %u\n",count*4);fflush(stdout);
 const unsigned char *p=(const unsigned char*)out;size_t left=count*4;
 while(left){ssize_t n=_write(1,p,left);if(n<=0||(size_t)n>left)return 4;p+=n;left-=n;}
 printf("\nBENCH_END\n");return good?0:5;
}
