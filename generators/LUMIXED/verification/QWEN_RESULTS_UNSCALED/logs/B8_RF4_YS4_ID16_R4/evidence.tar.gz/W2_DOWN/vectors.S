.section .rodata.vectors,"a",@progbits
.balign 8
.global bench_x
bench_x:
.incbin "input.bin"
.balign 8
.global bench_w
bench_w:
.incbin "weights.bin"
.section .note.GNU-stack,"",@progbits
